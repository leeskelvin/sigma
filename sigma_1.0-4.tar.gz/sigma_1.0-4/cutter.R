#!/usr/bin/Rscript --no-init-file
# SIGMA (Structural Investigation of Galaxies via Model Analysis)
# Written by Lee Kelvin

# cutter
cutter = function(bandnum = 1, galdat){
    
    # galname
    galname = galdat[,"GALNAME"]
    
    # image file definitions
    inpim = strsplit(galdat[,"INPIM"], " ")[[1]][bandnum]
    image = paste(indir,"/", inpim, sep="")
    cutim = "cutim.fits"
    
    # weight file definitions
    if("INPWT" %in% colnames(galdat)){
        inpwt = strsplit(galdat[,"INPWT"], " ")[[1]][bandnum]
        weight = paste(indir,"/", inpwt, sep="")
        cutwt = "cutwt.fits"
    }else{
        inpwt = "NA"
        weight = "NA"
        cutwt = "NA"
    }
    
    # does file exist?
    if(!file.exists(image)){
        
        cat("\n\n  ERROR: could not find '", image, "', check input directory!\n\n", sep="")
        quit(save="no")
        
    }
    
    # calculate pixel centroids
    if("RA" %in% colnames(dat)){
        
        xcen = system(paste(sky2xy,"-o x",image,galdat[,"RA"],galdat[,"DEC"]), intern=TRUE)
        ycen = system(paste(sky2xy,"-o y",image,galdat[,"RA"],galdat[,"DEC"]), intern=TRUE)
        gonebad = FALSE
        if(length(strsplit(xcen, "off image")[[1]])>1){gonebad = TRUE}else{xcen = as.numeric(xcen)}
        if(length(strsplit(ycen, "off image")[[1]])>1){gonebad = TRUE}else{ycen = as.numeric(ycen)}
        
        # sanity check - galaxy in frame
        if(gonebad){
            cat("\n  ERROR: object '", galdat[,"GALNAME"], "' RA/DEC not within image boundaries!\n  CHECK: ", sky2xy," ",image," ",galdat[,"RA"]," ",galdat[,"DEC"],"\n\n", sep="")
            break
        }
        
    }else{
        
        xcen = galdat[,"INPX"]
        ycen = galdat[,"INPY"]
        
    }
    
    # pixel scale and axis size
    temp = system(paste(imsize,image), intern=TRUE)
    pixsize = suppressWarnings(abs(as.numeric(strsplit(strsplit(temp, "s/pix")[[1]][1], "/")[[1]][2])))
    if(is.na(pixsize)){pixsize=1}
    #naxis1 = as.numeric(strsplit(strsplit(strsplit(temp, "s/pix")[[1]][2], " +")[[1]][2], "x")[[1]][1])
    #naxis2 = as.numeric(strsplit(strsplit(strsplit(temp, "s/pix")[[1]][2], " +")[[1]][2], "x")[[1]][2])
    naxis1 = as.numeric(read.fitskey(key="NAXIS1", file=image))
    naxis2 = as.numeric(read.fitskey(key="NAXIS2", file=image))
    
    # define lower and upper cuts
    cutradpix = round(cutrad/pixsize)
    lowerx = max((round(xcen)-cutradpix),1)
    upperx = min((round(xcen)+cutradpix),naxis1)
    lowery = max((round(ycen)-cutradpix),1)
    uppery = min((round(ycen)+cutradpix),naxis2)
    cutxcen = round(xcen)-(lowerx-1)
    cutycen = round(ycen)-(lowery-1)
    
    # cutout image
    if(file.exists(cutim)){file.remove(cutim)}
    cutcommandim = paste(fitscopy," ",image,"[",format(lowerx,scientific=FALSE),":",format(upperx,scientific=FALSE),",",format(lowery,scientific=FALSE),":",format(uppery,scientific=FALSE),"] ",cutim,sep="")
    system(cutcommandim)
    # multi-HDU fix (SIGMA cannot handle multi-HDU input images at present)
    tt = read.fits(cutim, hdu=1)
    unlink(cutim)
    # header keywords to keep
    goodkeys = c("CRVAL", "CRPIX", "CDELT", "CTYPE", "CROTA", "CUNIT", "WCSAXES", "PC1_1", "PC1_2", "PC2_1", "PC2_2", "CD1_1", "CD1_2", "CD2_1", "CD2_2", "PV1_1", "PV1_2", "PV2_1", "PV2_2", "PS1_1", "PS1_2", "PS2_1", "PS2_2")
    hdr = tt$hdr[[1]]
    goodvals = cbind(key=c("COMMENT","COMMENT","COMMENT","COMMENT","COMMENT"), value=c("","","","",""), comment=c("","#########################","WCS information carried over below","#########################",""))
    for(i in 1:length(goodkeys)){
        temp = grep(goodkeys[i], hdr[,"key"])
        goodvals = rbind(goodvals, hdr[temp,])
    }
    write.fits(list(dat=list(tt$dat[[1]]), hdr=list(goodvals)), file=cutim)
    
    # cutout weight
    if(weight!="NA"){
        if(file.exists(cutwt)){file.remove(cutwt)}
        cutcommandwt = paste(fitscopy," ",weight,"[",format(lowerx,scientific=FALSE),":",format(upperx,scientific=FALSE),",",format(lowery,scientific=FALSE),":",format(uppery,scientific=FALSE),"] ",cutwt,sep="")
        system(cutcommandwt)
        # multi-HDU fix (SIGMA cannot handle multi-HDU input images at present)
        tt = read.fits(cutwt, hdu=1)
        unlink(cutwt)
        write.fits(list(dat=list(tt$dat[[1]]), hdr=list(goodvals)), file=cutwt)
    }
    
    # add header information
    user = system("id -un", intern=TRUE)
    date = format(Sys.time(), "%Y-%m-%d@%H:%M:%S")
    keys = c("COMMENT", "COMMENT", "COMMENT", "SIGMA", "SIGUSER", "SIGDATE", "GALNAME", "INPIM")
    vals = c("", "", "", vnum, user, date, galname, inpim)
    coms = c("", "#########################", "", "SIGMA version number", "SIGMA user name", "SIGMA time-stamp", "SIGMA galaxy name", "SIGMA input FITS image")
    
    # check for header information
    checklist = list(hdrgain, hdrnois, hdrcomb, hdrexpt, hdrzero, hdrfwhm)
    checkdefs = c("GAIN", "RDNOISE", "NCOMBINE", "EXPTIME", "MAGZP", "PSFFWHM")
    checkcoms = c("Gain (e ADU^-1)", "Read Noise (e)", "Number of combined images", "Exposure time (s)", "Zero point magnitude (per second)", "PSF FWHM (arcsec)")
    #hdr = read.fitshdr(cutim)
    cutaxis1 = as.numeric(hdr[which(hdr[,"key"]=="NAXIS1"),"value"])
    cutaxis2 = as.numeric(hdr[which(hdr[,"key"]=="NAXIS2"),"value"])
    gain = {}
    for(i in 1:length(checklist)){
        
        check = checklist[[i]]
        if(length(check)>2){
            check = c(check[1], check[bandnum+1])
        }
        if(check[1] %in% hdr[,"key"]){
            check[2] = hdr[which(hdr[,"key"]==check[1]),"value"]
        }
        if(check[1]!=checkdefs[i]){
            check[1] = checkdefs[i]
        }
        
        # exposure time correction
        if(check[1]=="EXPTIME"){
            origexptime = check[2]
            if(as.numeric(origexptime)!=1 & countspersecond){
                tt = read.fits(cutim, hdu=1)
                tt$dat[[1]] = tt$dat[[1]] * as.numeric(origexptime)
                write.fits(tt, file=cutim)
                check[2] = 1
            }
            # remove below - change source extractor to accept unmatched per-second values for counts and zp
            if(as.numeric(origexptime)!=1 & !countspersecond){
                check[2] = 1
            }
        }
        
        # pick out zero point
        if(check[1]=="EXPTIME"){
            if(!magzppersecond){
                magzpcorrection = -2.5 * log10(as.numeric(origexptime))
            }
        }
        if(check[1]=="MAGZP"){
            zp = check[2]
            if(as.numeric(origexptime)!=1 & !magzppersecond){
                check[2] = zp = as.numeric(zp) - magzpcorrection
            }
        }
        
        # pick out gain
        if(check[1]=="GAIN"){
            gain = c(gain, check[2])
        }
        
        # add to keys/vals/coms
        keys = c(keys, check[1])
        vals = c(vals, check[2])
        coms = c(coms, checkcoms[i])
        
    }
    
    # write to FITS header
    write.fitskey(key=keys, value=vals, file=cutim, comment=coms, hdu=1)
    
    # update results
    extras = galdat[0]
    checklist = list(CUTIM=cutim, CUTWT=cutwt, PIXSIZE=pixsize, INPXCEN=xcen, INPYCEN=ycen, CUTXCEN=cutxcen, CUTYCEN=cutycen, CUTRADPIX=cutradpix, MAGZP=zp, CUTAXIS1=cutaxis1, CUTAXIS2=cutaxis2)
    for(i in 1:length(checklist)){
        
        if(names(checklist)[i]%in%colnames(galdat)){
            col = which(colnames(galdat)==names(checklist)[i])[1]
            galdat[,col] = paste(galdat[,col], checklist[[i]])
        }else{
            extras = cbind(extras, checklist[[i]])
            colnames(extras)[length(colnames(extras))] = names(checklist)[i]
        }
        
    }
    
    # return results
    galdat = cbind(galdat, extras, stringsAsFactors=FALSE)
    return(list(galdat=galdat, gain=gain))
    
}

