#!/usr/bin/Rscript --no-init-file
# SIGMA (Structural Investigation of Galaxies via Model Analysis)
# Written by Lee Kelvin

# simulated catalogue setup
simsetup = function(inputcat, band, simra, simdec, simmag, simre, simindex, simellip, simdir, simim, simband, simmult, simulate){
    
    if(simulate){
        
        # input catalogue
        inputcat = "simcat.img"
        
        # input directory
        indir = paste(simdir, collapse=" ")
        
        # input band column
        band = paste(simband, collapse="")
        
        # create simulated catalogue?
        if(!file.exists(inputcat)){
            
            # ra/dec
            p = length(simmag)*length(simre)*length(simindex)*length(simellip)*simmult
            ra = sample(simra,p)
            dec = sample(simdec,p)
            
            # simcat
            precat = expand.grid(simmag,simre,simindex,simellip)
            postpos = rep(1:length(precat[,1]),simmult)
            postcat = precat[postpos,]
            postcat = cbind(paste(postpos,"-v",rep(1:simmult,each=length(precat[,1])),sep=""),postpos,ra,dec,postcat,stringsAsFactors=FALSE)
            colnames(postcat) = c("GALNAME","SIMID","RA","DEC","SIMMAG","SIMRE","SIMINDEX","SIMELLIP")
            rownames(postcat) = NULL
            dat = postcat
            
            # input image column
            inpim = paste(simim, collapse=" ")
            dat = cbind(dat, INPIM=inpim, stringsAsFactors=FALSE)
            
            # input weight column
            inpwt = paste(simwt, collapse=" ")
            dat = cbind(dat, INPWT=inpwt, stringsAsFactors=FALSE)
            
            # save simulated catalogue
            save(dat, file=inputcat)
            
        }
        
    }
    
    # return outputs
    return(list(inputcat=inputcat, indir=indir, band=band))
    
}

# simulate
simgal = function(bandnum = 1, galdat){
    
    # input models
    models = grep("feedme",dir(moddir),value=T)
    if(length(grep("example",models))>0){models = models[-grep("example",models)]}
    if(length(grep("secondary",models))>0){models = models[-grep("secondary",models)]}
    if(length(grep("sky.feedme",models))>0){models = models[-grep("sky.feedme",models)]}
    if(length(grep("extras",models))>0){models = models[-grep("extras",models)]}
    if(length(grep("unused",models))>0){models = models[-grep("unused",models)]}
    cnum = {}
    modidents = {}
    for(k in 1:length(models)){
        cnum = c(cnum,length(grep("# Component number",readLines(paste(moddir,"/",models[k],sep="")))))
        modidents = c(modidents,strsplit(models[k],"_")[[1]][1])
    }
    
    # input definitions
    pixsize = as.numeric(strsplit(as.character(galdat[,"PIXSIZE"]), " ")[[1]][bandnum])
    X_IMAGE = as.numeric(strsplit(as.character(galdat[,"CUTXCEN"]), " ")[[1]][bandnum])
    Y_IMAGE = as.numeric(strsplit(as.character(galdat[,"CUTYCEN"]), " ")[[1]][bandnum])
    BACKGROUND = 0
    FLUX_RADIUS = KRON_RADIUS = SEXRE = galdat[,"SIMRE"] / pixsize  # convert to pixels
    ELLIPTICITY = galdat[,"SIMELLIP"]
    A_IMAGE = 1
    B_IMAGE = (1 - ELLIPTICITY) * A_IMAGE
    MAG_AUTO = galdat[,"SIMMAG"]
    THETA_IMAGE = 0
    CLASS_STAR = 0
    PIXSEP = 0
    SEXRA = galdat[,"RA"]
    SEXDEC = galdat[,"DEC"]
    refindex = galdat[,"SIMINDEX"]
    cutim = strsplit(galdat[,"CUTIM"], " ")[[1]][bandnum]
    psfim = strsplit(galdat[,"PSFIM"], " ")[[1]][bandnum]
    zp = as.numeric(strsplit(as.character(galdat[,"MAGZP"]), " ")[[1]][bandnum])
    pixsize = as.numeric(strsplit(as.character(galdat[,"PIXSIZE"]), " ")[[1]][bandnum])
    cutaxis1 = as.numeric(strsplit(as.character(galdat[,"CUTAXIS1"]), " ")[[1]][bandnum])
    cutaxis2 = as.numeric(strsplit(as.character(galdat[,"CUTAXIS2"]), " ")[[1]][bandnum])
    skysd = as.numeric(strsplit(as.character(galdat[,"SKYSD"]), " ")[[1]][bandnum])
    
    # output definitions
    base = strsplit(cutim,"cutim")[[1]][2]
    objim = paste("objim",base,sep="")
    fitim = "none"
    mskim = "none"
    constraints = "none"
    
    # fitting region
    xlo = 1
    xhi = cutaxis1
    ylo = 1
    yhi = cutaxis2
    
    # convolution region size
    xconv = ceiling(xhi-(xlo-1))
    yconv = ceiling(yhi-(ylo-1))
    
    # cutout image data
    cutim.dat = read.fits(cutim)
    
    k = 1
    
    # loop over each model
    simims = {}
    for(k in 1:1){
        
        # model setup
        modfile = models[k]
        #simim = paste("simim", k, ".fits", sep="")
        simim = "simim.fits"
        simims = c(simims, simim)
        
        # primary data matrix
        banddat = cbind(X_IMAGE=X_IMAGE, Y_IMAGE=Y_IMAGE, BACKGROUND=BACKGROUND, FLUX_RADIUS=FLUX_RADIUS, KRON_RADIUS=KRON_RADIUS, A_IMAGE=A_IMAGE, B_IMAGE=B_IMAGE, MAG_AUTO=MAG_AUTO, THETA_IMAGE=THETA_IMAGE, ELLIPTICITY=ELLIPTICITY, CLASS_STAR=CLASS_STAR, PIXSEP=PIXSEP, SEXRE=SEXRE, SEXRA=SEXRA, SEXDEC=SEXDEC)
    primary = cbind(FITIM=fitim, MODIM=simim, PSFIM=psfim, MSKIM=mskim, CONSTRAINTS=constraints, XLO=xlo, XHI=xhi, YLO=ylo, YHI=yhi, XCONV=xconv, YCONV=yconv, ZP=zp, PIXSIZE=pixsize, SKYRMS=skysd, REFINDEX=refindex, banddat)
        
        # secondary data matrix
        secondary = NULL
        
        # write feedme and constraints file
        comps = writefeedme(moddir = moddir, modfile = modfile, primary = primary, secondary = secondary)
        
        # run GALFIT
        galcommand = paste(galfit, "-o1 -skyped 0 -skyrms", primary[,"SKYRMS"], modfile)
        if(fulloutput){
            system(galcommand)
        }else{
            temp = suppressWarnings(system(galcommand, intern=TRUE))
        }
        
        # add simulated image to cutout image
        simim.dat = read.fits(simim)
        cutim.dat$dat[[1]] = cutim.dat$dat[[1]] + simim.dat$dat[[1]]
        unlink(simim)
        write.fits(cutim.dat, file=simim)
        
        # clean up
        unlink(modfile)
        
    }
    
    # update results
    extras = galdat[0]
    checklist = c(SIMIM = paste(simims, collapse=","))
    for(i in 1:length(checklist)){
        
        if(names(checklist)[i]%in%colnames(galdat)){
            col = which(colnames(galdat)==names(checklist)[i])[1]
            galdat[,col] = paste(galdat[,col], checklist[[i]])
        }else{
            extras = cbind(extras, checklist[[i]])
            colnames(extras)[length(colnames(extras))] = names(checklist)[i]
        }
        
    }
    
    # return results
    galdat = cbind(galdat, extras, stringsAsFactors=FALSE)
    return(galdat)
    
}

# collect simulations together
simclose = function(){
    
    # start message
    cat("----- Reducing SIGMA simulations...\n\n")
    
    # make sure other processes have finished
    Sys.sleep(3)
    
    # read in data
    dat = read.csv(catname)
    simids = dat[,"SIMID"]
    groups = unique(simids)
    
    i = 1
    
    for(i in 1:length(groups)){
        
        # notify
        cat("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b",i,"/",length(groups),"")
        
        # input data
        group = which(simids==groups[i])
        groupdat = dat[group,]
        
        # calculate medians of each column
        racols = c(grep("SEXRA", colnames(groupdat)), grep("GALRA", colnames(groupdat)))
        deccols = c(grep("SEXDEC", colnames(groupdat)), grep("GALDEC", colnames(groupdat)))
        mediandat = groupdat[1,0]
        for(j in 1:length(groupdat[1,])){
            
            coldat = groupdat[,j]
            if(j %in% racols){
                coldat = racols - groupdat[,"RA"]
            }
            if(j %in% deccols){
                coldat = racols - groupdat[,"DEC"]
            }
            mediandat = cbind(mediandat, suppressWarnings(median(coldat)))
            
        }
        colnames(mediandat) = colnames(groupdat)
        
        # fix galname column
        mediandat[,"GALNAME"] = mediandat[,"SIMID"]
        
        # move NA -> null
        if(any(is.na(mediandat))){
            bad = which(is.na(mediandat))
            mediandat[,bad] = null
        }
        
        # results
        if(i==1){
            cat(paste(colnames(mediandat),collapse=","),"\n",sep="",file="simcat.csv")
        }
        cat(paste(mediandat,collapse=","),"\n",sep="",append=TRUE,file="simcat.csv")
        
    }
    
    # clean up simulated input catalogue
    unlink("simcat.img")
    
    # end message
    cat("\n\n----- SIGMA Simulations reduced!\n\n")
    
}








