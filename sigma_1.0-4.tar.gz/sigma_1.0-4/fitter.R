#!/usr/bin/Rscript --no-init-file
# SIGMA (Structural Investigation of Galaxies via Model Analysis)
# Written by Lee Kelvin

# galaxy fitter
fitter = function(bandnum = 1, galdat, galdatfull, objlist){
    
    # input definitions
    cutim = strsplit(galdat[,"CUTIM"], " ")[[1]][bandnum]
    fitim = strsplit(galdat[,"FITIM"], " ")[[1]][bandnum]
    fitwt = strsplit(galdat[,"FITWT"], " ")[[1]][bandnum]
    segim = strsplit(galdat[,"SEGIM"], " ")[[1]][bandnum]
    psfim = strsplit(galdat[,"PSFIM"], " ")[[1]][bandnum]
    fitaxis1 = as.numeric(strsplit(as.character(galdat[,"FITAXIS1"]), " ")[[1]][bandnum])
    fitaxis2 = as.numeric(strsplit(as.character(galdat[,"FITAXIS2"]), " ")[[1]][bandnum])
    fitxcen = as.numeric(strsplit(as.character(galdat[,"FITXCEN"]), " ")[[1]][bandnum])
    fitycen = as.numeric(strsplit(as.character(galdat[,"FITYCEN"]), " ")[[1]][bandnum])
    pixsize = as.numeric(strsplit(as.character(galdat[,"PIXSIZE"]), " ")[[1]][bandnum])
    skyped = 0
    skysd = as.numeric(strsplit(as.character(galdat[,"SKYSD"]), " ")[[1]][bandnum])
    skyerr = as.numeric(skysd)/sqrt(0.90*as.numeric(fitaxis1)*as.numeric(fitaxis2))
    zp = as.numeric(strsplit(as.character(galdat[,"MAGZP"]), " ")[[1]][bandnum])
    objdat = objlist[[bandnum]]
    
    # output definitions
    base = strsplit(cutim,"cutim")[[1]][2]
    if(is.na(base)){base = strsplit(cutim,"simim")[[1]][2]}
    objim = paste("objim",base,sep="")
    constraints = "constraints.dat"
    
    # strip bandnum values from galdat
    sexparams = c(as.vector(t(read.table(detparam))), "PIXSEP", "SEXRE", "SEXMU0N1", "SEXMU0N4", "SEXMUEN1", "SEXMUEN4", "SEXRA", "SEXDEC")
    banddat = {}
    for(i in 1:length(sexparams)){
        
        col = which(colnames(galdat)==sexparams[i])
        val = as.numeric(strsplit(as.character(galdat[,col]), " ")[[1]][bandnum])
        banddat = cbind(banddat, val)
        colnames(banddat)[i] = sexparams[i]
        
    }
    
    # input models
    models = grep("feedme",dir(moddir),value=T)
    if(length(grep("example",models))>0){models = models[-grep("example",models)]}
    if(length(grep("secondary",models))>0){models = models[-grep("secondary",models)]}
    if(length(grep("sky.feedme",models))>0){models = models[-grep("sky.feedme",models)]}
    if(length(grep("extras",models))>0){models = models[-grep("extras",models)]}
    if(length(grep("unused",models))>0){models = models[-grep("unused",models)]}
    cnum = {}
    modidents = {}
    for(k in 1:length(models)){
        cnum = c(cnum,length(grep("# Component number",readLines(paste(moddir,"/",models[k],sep="")))))
        modidents = c(modidents,strsplit(models[k],"_")[[1]][1])
    }
    
    # galfit component and global keys
    galcompkeys = c("_XC", "_YC", "_MAG", "_MUBRK", "MU_0", "_RE", "_N", "_AR", "_PA", "_F1", "_F1PA", "_C0")
    galtrnckeys = c("_INNER", "_OUTER", "_RBRK", "_RSFT")
    galglobkeys = c("CHISQ", "NDOF", "CHI2NU")
    
    # galfit and value-added component and global names
    galcompbase = c("galxcen", "galycen", "galmag", "galmubreak", "galmucentral", "galre", "galindex", "galellip", "galpa", "galf1", "galf1pa", "galboxydisky")
    galcomperrbase = paste(galcompbase, "err", sep="")
    galtrncbase = c("galinner", "galouter", "galbreak", "galsoft")
    galtrncerrbase = paste(galtrncbase, "err", sep="")
    galtrnibase = c("galinnerinner", "galinnerouter", "galinnerbreak", "galinnersoft")
    galtrnierrbase = paste(galtrnibase, "err", sep="")
    galtrnobase = c("galouterinner", "galouterouter", "galouterbreak", "galoutersoft")
    galtrnoerrbase = paste(galtrnobase, "err", sep="")
    galglobbase = c("galchi2full", "galndof", "galchi2")
    valcompbase = c("galra", "galdec", "galmag10re", "galmu0", "galmue", "galmueavg", "galr90", "galfracl", "galfracl10re")
    valglobbase = c("galplan", "galxlo", "galxhi", "galylo", "galyhi", "galmagtot", "galmag10retot", "prichi2full", "prinfp", "prindof", "prichi2", "bic")
    
    # convolution region size
    xconv = fitaxis1
    yconv = fitaxis2
    
    # primary data matrix
    primary = cbind(FITIM=fitim, FITWT=fitwt, MODIM=null, MSKIM=null, SEGIM=segim, PSFIM=psfim, OBJIM=objim, CONSTRAINTS=constraints, PIXSIZE=pixsize, SKYPED=skyped, SKYRMS=skysd, banddat, XLO=1, XHI=fitaxis1, YLO=1, YHI=fitaxis2, XCONV=xconv, YCONV=yconv, ZP=zp, REFINDEX=refindex)
    
    # masters
    mast_primary = primary
    
    # mask data
    segim.dat = read.fits(primary[,"SEGIM"])
    
    k = 1
    
    # loop over each model    
    galresults = galresultsfull = galdat[0]
    modims = {}
    mskims = {}
    for(k in 1:length(models)){
        
        # model-specific definitions
        modident = modidents[k]
        modfile = models[k]
        
        # only run galfits if a primary object exists
        if(as.numeric(primary[,"MAG_AUTO"]) != null){
            
            # restore masters
            primary = mast_primary
            
            # primary definitions
            primary[,"MODIM"] = paste(modident,"_",objim,sep="")
            primary[,"MSKIM"] = paste(modident,"_mskim.fits",sep="")
            primary[,"CONSTRAINTS"] = paste(modident,"_constraints.dat",sep="")
            
            # secondary data matrix
            secondary = trimsec(xlo = 1, xhi = fitaxis1, ylo = 1, yhi = fitaxis2, buffer = 3, maxnum = fitmax, objdat = objdat)
            
            # backups
            bak_primary = primary
            bak_secondary = secondary
            
            # galfit #2 - shrink fitting region (only try this fix if a very bright nearby neighbour exists)
            if(length(bak_secondary) > 2){
                
                # calculate secondary flux contributions at centroid of primary (assume n1=1, n2=4, e=0)
                primu = sersic(mag = as.numeric(bak_primary[,"MAG_AUTO"]), re = as.numeric(bak_primary[,"FLUX_RADIUS"]), n = 1, e = 0, r = 0)$mu
                secmu = sersic(mag = as.numeric(bak_secondary[,"MAG_AUTO"]), re = as.numeric(bak_secondary[,"FLUX_RADIUS"]), n = 4, e = 0, r = as.numeric(bak_secondary[,"PIXSEP"]))$mu
                
                # secondary surface brightness check
                if(any(is.na(secmu))){
                    secmu[is.na(secmu)] = 9999
                }
                
                # any secondaries SB brighter than -3 mags at centroid of primary
                if(any(primu - secmu > -3)){
                #if(any(as.numeric(bak_primary[,"MAG_AUTO"]) - as.numeric(bak_secondary[,"MAG_AUTO"]) > 3)){
                    
                    galplan = 2
                    out = galfit2(primary = bak_primary, moddir, modfile, objdat, fitaxis1, fitaxis2, fitxcen, fitycen, segim.dat)
                    primary = out$primary; secondary = out$secondary; comps = out$comps
                    
                }
                
            }
            
            # galfit #1
            if(!file.exists(primary[,"MODIM"])){
                
                galplan = 1
                out = galfit1(primary = bak_primary, moddir, modfile, objdat, fitaxis1, fitaxis2, fitxcen, fitycen, segim.dat)
                primary = out$primary; secondary = out$secondary; comps = out$comps
                
            }
            
            # galfit #3a - jiggle fitting parameters up (larger/brighter) (up first, then down - more flux good)
            if(!file.exists(primary[,"MODIM"])){
                
                galplan = 3
                out = galfit3(primary = bak_primary, moddir, modfile, objdat, fitaxis1, fitaxis2, fitxcen, fitycen, segim.dat, jiggle = "up")
                primary = out$primary; secondary = out$secondary; comps = out$comps
                
            }
            
            # galfit #3b - jiggle fitting parameters down (smaller/fainter)
            if(!file.exists(primary[,"MODIM"])){
                
                galplan = 3
                out = galfit3(primary = bak_primary, moddir, modfile, objdat, fitaxis1, fitaxis2, fitxcen, fitycen, segim.dat, jiggle = "down")
                primary = out$primary; secondary = out$secondary; comps = out$comps
                
            }
            
            # galfit #4 - mask all secondaries
            if(!file.exists(primary[,"MODIM"])){
                
                galplan = 4
                out = galfit4(primary = bak_primary, moddir, modfile, objdat, fitaxis1, fitaxis2, fitxcen, fitycen, segim.dat)
                primary = out$primary; secondary = out$secondary; comps = out$comps
                
            }
            
            # galfit #5 - no constraints
            if(!file.exists(primary[,"MODIM"])){
                
                galplan = 5
                out = galfit5(primary = bak_primary, moddir, modfile, objdat, fitaxis1, fitaxis2, fitxcen, fitycen, segim.dat)
                primary = out$primary; secondary = out$secondary; comps = out$comps
                
            }
            
        }
        
        # only continue to process if an output file has been produced
        if(file.exists(primary[,"MODIM"])){
            
            # read results (and errors)
            objimdat = read.fits(primary[,"MODIM"])
            modhdr = objimdat$hdr[[3]]
            galbad = {}     # columns to later be removed
            galres = {}
            galerr = {}
            trnres = {}
            trnerr = {}
            valres = {}
            
            # loop over each primary component
            for(i in 1:length(comps$pricomps)){
                
                # loop over each GALFIT header value
                gbad = {}
                gres = {}
                gerr = {}
                for(j in 1:length(galcompkeys)){
                    
                    hdrrow = which(modhdr[,"key"]==paste(comps$pricomps[i],galcompkeys[j],sep=""))
                    
                    if(length(hdrrow)>0){
                        
                        hdrkey = strsplit(modhdr[hdrrow,"value"], " +")[[1]]
                        res = strip(hdrkey[1], c("{","["," ","*","]","}"))
                        err = strip(hdrkey[3], c("{","["," ","*","]","}"))
                        
                        if(err == ""){err = null}
                        
                        # position angle convention fix
                        if(galcompbase[j] == "galpa"){
                            
                            res = as.numeric(res) + 90
                            if(res>90){res = res - 180}
                            
                        }
                        
                        # axis ratio to ellipticity conversion
                        if(galcompbase[j] == "galellip"){
                            
                            res = 1 - as.numeric(res)
                            
                        }
                        
                    }else{
                        
                        res = err = null
                        gbad = c(gbad, j)
                        
                    }
                    
                    gres = cbind(gres, res)
                    gerr = cbind(gerr, err)
                    
                }
                
                # galcomp names
                compid = formatC(comps$pricomps[i],width=2,flag=0)
                colnames(gres) = paste(galcompbase, compid, sep="_")
                colnames(gerr) = paste(galcomperrbase, compid, sep="_")
                
                # value added component results
                cx = as.numeric(gres[,grep(paste("galxcen",compid,sep="_"), colnames(gres))])
                cy = as.numeric(gres[,grep(paste("galycen",compid,sep="_"), colnames(gres))])
                cmag = as.numeric(gres[,grep(paste("galmag",compid,sep="_"), colnames(gres))])
                cre = as.numeric(gres[,grep(paste("galre",compid,sep="_"), colnames(gres))])
                if(cre != null){cre = cre * pixsize}
                cn = as.numeric(gres[,grep(paste("galindex",compid,sep="_"), colnames(gres))])
                ce = as.numeric(gres[,grep(paste("galellip",compid,sep="_"), colnames(gres))])
                
                # RA/Dec
                temp = xy2radec(x=cx, y=cy, file=fitim, xy2sky=xy2sky)
                cra = temp[1]
                cdec = temp[2]
                
                # sersic info
                s0 = suppressWarnings(sersic(mag = cmag, re = cre, n = cn, e = ce, r = 0*cre))
                s1 = suppressWarnings(sersic(mag = cmag, re = cre, n = cn, e = ce, r = 1*cre))
                s10 = suppressWarnings(sersic(mag = cmag, re = cre, n = cn, e = ce, r = 10*cre))
                
                # other
                r90 = suppressWarnings(convrad(n = cn, f = 0.9, r = cre, fr = 0.5))
                galfrac = 10^(-0.4 * cmag)
                galfrac10 = 10^(-0.4 * s10$mag)
                
                # create value-added result array
                vres = cbind(cra, cdec, s10$mag, s0$mu, s1$mu, s1$muavg, r90, galfrac, galfrac10)
                colnames(vres) = paste(valcompbase, compid, sep="_")
                if(any(is.nan(vres))){vres[which(is.nan(vres))] = null}
                
                # collect results
                galbad = c(galbad, list(gbad))
                galres = c(galres, list(gres))
                galerr = c(galerr, list(gerr))
                valres = c(valres, list(vres))
                
            }
            
            # loop over each truncation component
            if(length(comps$trncomps) > 0){
                
                for(i in 1:length(comps$trncomps)){
                    
                    # loop over each GALFIT header value
                    tres = {}
                    terr = {}
                    for(j in 1:length(galtrnckeys)){
                        
                        hdrrow = which(modhdr[,"key"]==paste(comps$trncomps[i],galtrnckeys[j],sep=""))
                        
                        if(length(hdrrow)>0){
                            
                            hdrkey = strsplit(modhdr[hdrrow,"value"], " +")[[1]]
                            res = strip(hdrkey[1], c("{","["," ","*","]","}"))
                            err = strip(hdrkey[3], c("{","["," ","*","]","}"))
                            
                            if(err == ""){err = null}
                            
                        }else{
                            
                            res = err = null
                            
                        }
                        
                        tres = cbind(tres, res)
                        terr = cbind(terr, err)
                        
                    }
                    
                    # temporary galtrnc names
                    ires = ores = tres
                    ierr = oerr = terr
                    colnames(ires) = paste(galtrnibase)
                    colnames(ierr) = paste(galtrnierrbase)
                    colnames(ores) = paste(galtrnobase)
                    colnames(oerr) = paste(galtrnoerrbase)
                    colnames(tres) = paste(galtrncbase)
                    colnames(terr) = paste(galtrncerrbase)
                    galinners = as.numeric(tres[,"galinner"])
                    galouters = as.numeric(tres[,"galouter"])
                    if(any(galinners==0)){galinners = galinners[-which(galinners==0)]}
                    if(any(galouters==0)){galouters = galouters[-which(galouters==0)]}
                    
                    # primary inner-truncation ownerships
                    if(length(galinners) > 0){
                        for(j in 1:length(galinners)){
                            galinnernum = galinners[j]
                            galinnerid = formatC(galinnernum,width=2,flag=0)
                            breaksofts = which(galtrncbase %in% c("galbreak","galsoft"))
                            tempres = t(ires[,breaksofts])
                            temperr = t(ierr[,breaksofts])
                            colnames(tempres) = paste(colnames(tempres), galinnerid, sep="_")
                            colnames(temperr) = paste(colnames(temperr), galinnerid, sep="_")
                            galres[[galinnernum]] = cbind(galres[[galinnernum]], tempres)
                            galerr[[galinnernum]] = cbind(galerr[[galinnernum]], temperr)
                        }
                    }
                    
                    # primary outer-truncation ownerships
                    if(length(galouters) > 0){
                        for(j in 1:length(galouters)){
                            galouternum = galouters[j]
                            galouterid = formatC(galouternum,width=2,flag=0)
                            breaksofts = which(galtrncbase %in% c("galbreak","galsoft"))
                            tempres = t(ores[,breaksofts])
                            temperr = t(oerr[,breaksofts])
                            colnames(tempres) = paste(colnames(tempres), galouterid, sep="_")
                            colnames(temperr) = paste(colnames(temperr), galouterid, sep="_")
                            galres[[galouternum]] = cbind(galres[[galouternum]], tempres)
                            galerr[[galouternum]] = cbind(galerr[[galouternum]], temperr)
                        }
                    }
                    
                }
                
            }
            
            # unlist galres/galerr/valres lists
            galres = as.data.frame(galres)
            galerr = as.data.frame(galerr)
            valres = as.data.frame(valres)
            
            # global GALFIT header results
            gres = {}
            for(j in 1:length(galglobkeys)){
                
                hdrrow = which(modhdr[,"key"]==galglobkeys[j])
                
                if(length(hdrrow)>0){
                    
                    hdrkey = strsplit(modhdr[hdrrow,"value"], " +")[[1]]
                    res = strip(hdrkey[1], c("{","["," ","*","]","}"))
                    
                }else{
                    
                    res = err = null
                    
                }
                
                gres = cbind(gres, res)
                
            }
            
            # galglob names
            colnames(gres) = galglobbase
            
            # total magnitudes
            mags = as.numeric(galres[,grep("galmag", colnames(galres))])
            fluxes = 10^(-0.4*mags)
            fluxtot = sum(fluxes)
            magtot = -2.5*log10(fluxtot)
            mags10 = as.numeric(valres[,grep("galmag", colnames(valres))])
            fluxes10 = 10^(-0.4*mags10)
            fluxtot10 = sum(fluxes10)
            magtot10 = -2.5*log10(fluxtot10)
            
            # fix luminosity fraction columns
            fraccols = grep("galfracl_", colnames(valres))
            valres[,fraccols] = valres[,fraccols]/fluxtot
            fraccols10 = grep("galfracl10re_", colnames(valres))
            valres[,fraccols10] = valres[,fraccols10]/fluxtot10
            
            # subcomponent image
            galfile = system("ls -t *galfit*",intern=T)[1]
            temp = suppressWarnings(system(paste(galfit, "-o3 -skyped", skyped, galfile), intern=TRUE))
            subcomps = read.fits("subcomps.fits", hdu=0)$dat
            xaxis = dim(subcomps[[1]])[1]
            yaxis = dim(subcomps[[1]])[2]
            skyrms = grep(", RMS = ", temp, value=TRUE)
            skyrms = as.numeric(strsplit(strsplit(skyrms, ", RMS = ")[[1]][2], " ADUs.")[[1]][1])
            
            # primary model image
            prinum = 2 + comps$pricomps
            primod = matrix(0, xaxis, yaxis)
            for(e in prinum){
                primod = primod+subcomps[[e]]
            }
            
            # secondary model image
            secnum = 2 + comps$seccomps - length(comps$trncomps)
            secmod = matrix(0, xaxis, yaxis)
            if(length(secnum)>0){
                for(e in secnum){
                    secmod = secmod+subcomps[[e]]
                }
            }
            
            # primary data image
            pridat = subcomps[[2]] - secmod
            
            # primary sigma image
            prisig = read.fits("sigma.fits")$dat[[1]]
            
#            # primary sigma image
#            gain = as.numeric(read.fitskey("GAIN",file=primary[,"MODIM"],hdu=2))
#            prisig = pridat
#            prisig[prisig<0] = 0
#            prisig = sqrt((prisig/gain)+(skyrms^2))
            
            # cut segmentation map to fitted region
            segmap = read.fits(primary[,"SEGIM"])$dat[[1]]
            xlo = as.numeric(primary[,"XLO"])
            xhi = as.numeric(primary[,"XHI"])
            ylo = as.numeric(primary[,"YLO"])
            yhi = as.numeric(primary[,"YHI"])
            segmap = segmap[xlo:xhi,ylo:yhi]
            
            # find primary SEx value on segmap
            xfit = as.numeric(primary[,"X_IMAGE"]) - (as.numeric(primary[,"XLO"]) - 1)
            yfit = as.numeric(primary[,"Y_IMAGE"]) - (as.numeric(primary[,"YLO"]) - 1)
            prival = segmap[xfit,yfit]
            if((prival==0) | (galdat[,"PIXSEP"]==null)){
                xseglo = xfit-10
                xseghi = xfit+10
                yseglo = yfit-10
                yseghi = yfit+10
                if(xseglo < 1){xseglo = 1}
                if(xseghi > xaxis){xseghi = xaxis}
                if(yseglo < 1){yseglo = 1}
                if(yseghi > yaxis){yseghi = yaxis}
                segmap[xseglo:xseghi,yseglo:yseghi] = -1
                prival = -1
            }
            
            # add segmap to blank hdu1 in objim (modim)
            modim = read.fits(primary[,"MODIM"])
            modim$dat[[1]] = segmap
            write.fits(modim, file=primary[,"MODIM"])
            
            # number of free parameters
            galout = readLines(galfile)
            galends = grep("Z)", galout)
            prinfp = 0
            for(a in 1:length(comps$pricomps)){
                
                linestart = grep(paste("# Component number: ",comps$pricomps[a],sep=""),galout)[1]
                lineend = min(galends[which(galends>linestart)])
                for(b in linestart:lineend){
                    
                    temp = strsplit(galout[b],"#")[[1]][1]
                    temp = strsplit(temp," 1 ")[[1]]
                    while(length(temp)>1){
                        temp = paste(temp,collapse=" ")
                        temp = strsplit(temp," 1 ")[[1]]
                        prinfp = prinfp+1
                    }
                    
                }
                
            }
            
            # number of primary pixels
            prinpix = length(which(segmap%in%prival))
            # small number of pixels fix
            if(prinpix<=(prinfp+1)){
                
                prival = unique(as.numeric(segmap[(xfit-1):(xfit+1),(yfit-1):(yfit+1)]))
                if(0%in%prival){prival=prival[-which(prival==0)]}
                prinpix = length(which(segmap%in%prival))
                if(prinpix<=(prinfp+1)){
                    
                    segrange = ceiling(sqrt(prinfp)/2)
                    segmap[(xfit-segrange):(xfit+segrange),(yfit-segrange):(yfit+segrange)] = -1
                    prival = -1
                    prinpix = length(which(segmap%in%prival))
                    
                }
                
            }
            
            # number of degrees of freedom
            prindof = (prinpix-prinfp)
            
            # primary Chi2
            prichi2full = sum(((pridat[segmap%in%prival] - primod[segmap%in%prival])^2) / ((prisig[segmap%in%prival])^2))
            prichi2 = prichi2full/prindof
            
            # bayesian information criterion
            bic = prichi2full + (prinfp * log(prinpix))
            
            # collect valglobbase results
            vres = cbind(galplan, primary[,"XLO"], primary[,"XHI"], primary[,"YLO"], primary[,"YHI"], magtot, magtot10, prichi2full, prinfp, prindof, prichi2, bic)
            colnames(vres) = valglobbase
            
            # collect all results
            results = cbind(galres, galerr, valres, gres, vres)
            if(any(results=="Inf")){results[which(results=="Inf")]=null}
            if(any(results=="-Inf")){results[which(results=="-Inf")]=null}
            
        }else{
            
            # estimate number of primary components if no initial primary was detected
            if(as.numeric(primary[,"MAG_AUTO"]) == null){
                
                ncomps = length(grep(" 0) ", readLines(paste(moddir,"/",models[k],sep="")), val=T))
                comps = list(pricomps=1:ncomps, trncomps=NULL, seccomps=NULL)
                
            }
            
            # create fake results name array
            gres = {}
            gerr = {}
            vres = {}
            for(i in 1:length(comps$pricomps)){
                
                compid = formatC(i,width=2,flag=0)
                gres = c(gres, paste(galcompbase, compid, sep="_"))
                gerr = c(gerr, paste(galcomperrbase, compid, sep="_"))
                vres = c(vres, paste(valcompbase, compid, sep="_"))
                
            }
            resnames = c(gres, gerr, vres, galglobbase, valglobbase)
            
            # create null array
            results = {}
            for(i in 1:length(resnames)){results = cbind(results, null)}
            colnames(results) = resnames
            
            # galplan
            results[,"galplan"] = 0
            
        }
        
        # format and print results
        printline = readLines(paste(moddir,"/",models[k],sep=""))[1]
        printline = strsplit(printline,"# ")[[1]][2]
        printline = paste(" :", parseline(inpline=printline, repdat=results, maxchar=4))
        if(k>1){printline = paste("                ", printline, sep="")}
        cat(printline, "\n", sep="")
        
        # calculate model specific 
        modnum = strsplit(strsplit(models[k], ".feedme")[[1]],"_")[[1]][1]
        modname = paste(strsplit(strsplit(models[k], ".feedme")[[1]],"_")[[1]][-1],collapse="")
        npri = length(comps$pricomps)
        nsec = length(comps$seccomps)
        
        # add results to header of objim
        hdrresults = c(modnum, modname, npri, nsec, "", "", "", as.numeric(results))
        hdrnames = c("MODNUM", "MODNAME", "NCOMPS", "NSEC", "COMMENT", "COMMENT", "COMMENT", toupper(colnames(results)))
        hdrcoms = c("Model number", "Model name", "Number of primary components", "Number of secondary objects", "", "#########################", "")
        if(file.exists(primary[,"MODIM"])){
            write.fitskey(key=hdrnames, value=hdrresults, file=primary[,"MODIM"], comment=hdrcoms, hdu=2)
        }
        
        # clean up folder
        namefix = c("fit.log","galfit.","subcomps.fits")
        for(g in 1:length(namefix)){
            files = grep(namefix[g],dir(),val=T)
            if(length(files)>=1){
                for(f in 1:length(files)){
                    if(length(strsplit(files[f],"_")[[1]])==1){
                        file.rename(files[f],paste(modident,"_",files[f],sep=""))
                    }
                }
            }
        }
        
        # update modims/mksims
        modims = c(modims, primary[,"MODIM"])
        mskims = c(mskims, primary[,"MSKIM"])
        
        # read feedme file and trim away unneeded parts
        feedfile = readLines(paste(moddir,"/",modfile,sep=""))
        if(strsplit(strsplit(feedfile[1]," +")[[1]],"")[[1]][1]=="#"){feedfile = feedfile[-1]}
        
        # determine primary/truncation component lines and numbers
        prilines = grep(" 0) ", feedfile)
        trnlines = grep("T0) ", feedfile)
        complines = sort(c(prilines,trnlines,length(feedfile)))
        pricomps = which(complines %in% prilines)
        trncomps = which(complines %in% trnlines)
        
        # determine fitting parameters to remove from results data frame
        badres = {}
        baderr = {}
        for(g in 1:length(pricomps)){
            
            compid = formatC(pricomps[g],width=2,flag=0)
            basenum = which(complines==prilines[g])
            baserange = (complines[basenum]) : (complines[basenum+1]-1)
            temp = strsplit(feedfile[baserange[1]], " +")[[1]]
            if(any(temp=="")){temp = temp[-which(temp=="")]}
            basefunc = temp[2]
            compfile = feedfile[baserange]
            pars = {}
            for(h in 1:length(compfile)){
                temp = strsplit(compfile[h], " +")[[1]]
                if(any(temp=="")){temp = temp[-which(temp=="")]}
                if(length(temp)>0){
                    temp2 = strsplit(temp[1], "")[[1]][1]
                    if(temp2 != "#"){
                        pars = c(pars, temp[1])
                    }
                }
            }
            dels = {}
            # magnitude/mubreak/mucentral decision
            if(basefunc=="sersic3" & "Ti)"%in%pars){
                dels = c(dels, "galmag", "galmucentral")
            }else if(basefunc=="sersic3" & "To)"%in%pars){
                dels = c(dels, "galmag", "galmubreak")
            }else{
                dels = c(dels, "galmubreak", "galmucentral")
            }
            # PSF specific decisions
            if(basefunc=="psf"){
                dels = c(dels, "galre", "galindex", "galellip", "galpa")
            }
            # additional par decisions
            if(!"F1)"%in%pars){
                dels = c(dels, c("galf1","galf1pa"))
            }
            if(!"C0)"%in%pars){
                dels = c(dels, c("galboxydisky"))
            }
            bres = paste(dels,compid,sep="_")
            berr = paste(paste(dels,"err",sep=""),compid,sep="_")
            
            # add to total bads
            badres = c(badres, bres)
            baderr = c(baderr, berr)
        }
        
        # fix results to be same format as galdat
        results = cbind(galdat[0], results)
        
        # remove bad columns
        badnames = c(badres, baderr)
        badnums = {}
        for(g in 1:length(badnames)){
            if(badnames[g] %in% colnames(results)){badnums = c(badnums, which(colnames(results)==badnames[g]))}
        }
        resultsfull = results
        if(length(badnums)>0){
            results = results[,-badnums]
        }
        
        # add modident to results column names
        colnames(results) = toupper(paste(modident,colnames(results),sep="_"))
        colnames(resultsfull) = toupper(paste(modident,colnames(resultsfull),sep="_"))
        
        # add results to total results
        galresults = cbind(galresults, results)
        galresultsfull = cbind(galresultsfull, resultsfull)
        
    }
    
    # remove bad values
    bads = {}
    if(any(t(unlist(galresults))=="NA")){bads = c(bads, which(t(unlist(galresults))=="NA"))}
    if(any(t(unlist(galresults))=="NaN")){bads = c(bads, which(t(unlist(galresults))=="NaN"))}
    if(any(t(unlist(galresults))=="Inf")){bads = c(bads, which(t(unlist(galresults))=="Inf"))}
    if(any(t(unlist(galresults))=="-Inf")){bads = c(bads, which(t(unlist(galresults))=="-Inf"))}
    if(length(bads)>0){galresults[,bads] = null}
    badsfull = {}
    if(any(t(unlist(galresultsfull))=="NA")){badsfull = c(badsfull, which(t(unlist(galresultsfull))=="NA"))}
    if(any(t(unlist(galresultsfull))=="NaN")){badsfull = c(badsfull, which(t(unlist(galresultsfull))=="NaN"))}
    if(any(t(unlist(galresultsfull))=="Inf")){badsfull = c(badsfull, which(t(unlist(galresultsfull))=="Inf"))}
    if(any(t(unlist(galresultsfull))=="-Inf")){badsfull = c(badsfull, which(t(unlist(galresultsfull))=="-Inf"))}
    if(length(badsfull)>0){galresultsfull[,badsfull] = null}
    
    # update results
    extras = galdat[0]
    checklist = c(MODID = paste(modidents, collapse=","), MODIM = paste(modims, collapse=","), MSKIM = paste(mskims, collapse=","), as.list(galresults))
    for(i in 1:length(checklist)){
        
        if(names(checklist)[i]%in%colnames(galdat)){
            col = which(colnames(galdat)==names(checklist)[i])[1]
            galdat[,col] = paste(galdat[,col], checklist[[i]])
        }else{
            extras = cbind(extras, checklist[[i]])
            colnames(extras)[length(colnames(extras))] = names(checklist)[i]
        }
        
    }
    
    # update resultsfull
    extrasfull = galdatfull[0]
    checklist = c(MODID = paste(modidents, collapse=","), MODIM = paste(modims, collapse=","), MSKIM = paste(mskims, collapse=","), as.list(galresultsfull))
    for(i in 1:length(checklist)){
        
        if(names(checklist)[i]%in%colnames(galdatfull)){
            col = which(colnames(galdatfull)==names(checklist)[i])[1]
            galdatfull[,col] = paste(galdatfull[,col], checklist[[i]])
        }else{
            extrasfull = cbind(extrasfull, checklist[[i]])
            colnames(extrasfull)[length(colnames(extrasfull))] = names(checklist)[i]
        }
        
    }
    
    # return results
    galdat = cbind(galdat, extras, stringsAsFactors=FALSE)
    galdatfull = cbind(galdatfull, extrasfull, stringsAsFactors=FALSE)
    return(list(galdat=galdat, galdatfull=galdatfull))
    
}

# galfit #1 - main galfit setup and operation
galfit1 = function(primary, moddir, modfile, objdat, fitaxis1, fitaxis2, fitxcen, fitycen, segim.dat){
    
    # secondary data matrix
    secondary = trimsec(xlo = 1, xhi = fitaxis1, ylo = 1, yhi = fitaxis2, buffer = 3, maxnum = fitmax, objdat = objdat)
    
    # write feedme and constraints file
    comps = writefeedme(moddir = moddir, modfile = modfile, primary = primary, secondary = secondary)
    writeconstraints(moddir = moddir, modfile = modfile, primary = primary, secondary = secondary)
    
    # create mask image
    maskdat = segim.dat
    xvals = c(primary[,"X_IMAGE"],secondary[,"X_IMAGE"])
    yvals = c(primary[,"Y_IMAGE"],secondary[,"Y_IMAGE"])
    modvals = maskdat$dat[[1]][cbind(as.numeric(xvals),as.numeric(yvals))]
    if(any(modvals==0)){modvals = modvals[-which(modvals==0)]}
    if(any(modvals>0)){maskdat$dat[[1]][maskdat$dat[[1]]%in%modvals] = 0}
    write.fits(maskdat,file=primary[,"MSKIM"])
    
    # run GALFIT
    galcommand = paste(galfit, "-outsig -skyped", primary[,"SKYPED"], "-skyrms", primary[,"SKYRMS"], modfile)
    if(fulloutput){
        system(galcommand)
    }else{
        temp = suppressWarnings(system(galcommand, intern=TRUE))
    }
    
    # return number of components
    return(list(primary = primary, secondary = secondary, comps = comps))
    
}

# galfit #2 - shrink fitting region         
galfit2 = function(primary, moddir, modfile, objdat, fitaxis1, fitaxis2, fitxcen, fitycen, segim.dat){
    
    # new small radii
    smallrad = 15
    xlo = max(floor(round(fitxcen)-round(smallrad)), 1)
    xhi = min(ceiling(round(fitxcen)+round(smallrad)), fitaxis1)
    ylo = max(floor(round(fitycen)-round(smallrad)), 1)
    yhi = min(ceiling(round(fitycen)+round(smallrad)), fitaxis2)
    
    # check new limits encompass primary object - redefine if not
    buffer = 3
    ximage = round(as.numeric(primary[,"X_IMAGE"]))
    yimage = round(as.numeric(primary[,"Y_IMAGE"]))
    xrange = (xlo+buffer):(xhi-buffer)
    yrange = (ylo+buffer):(yhi-buffer)
    if( (!ximage %in% xrange) | (!yimage %in% yrange) ){
        xlo = max(floor(round(ximage)-round(smallrad)), 1)
        xhi = min(ceiling(round(ximage)+round(smallrad)), fitaxis1)
        ylo = max(floor(round(yimage)-round(smallrad)), 1)
        yhi = min(ceiling(round(yimage)+round(smallrad)), fitaxis2)
    }
    
    # implement new limits
    primary[,"XLO"] = xlo
    primary[,"XHI"] = xhi
    primary[,"YLO"] = ylo
    primary[,"YHI"] = yhi
    primary[,"XCONV"] = length(xlo:xhi)
    primary[,"YCONV"] = length(ylo:yhi)
    primary[,"MAG_AUTO"] = as.numeric(primary[,"MAG_AUTO"])+1
    primary[,"FLUX_RADIUS"] = as.numeric(primary[,"FLUX_RADIUS"])*0.5
    primary[,"SEXRE"] = as.numeric(primary[,"SEXRE"])*0.5
    primary[,"THETA_IMAGE"] = as.numeric(primary[,"THETA_IMAGE"]) - 90
    primary[,"ELLIPTICITY"] = 0
    
    # secondary data matrix
    secondary = trimsec(xlo = xlo, xhi = xhi, ylo = ylo, yhi = yhi, buffer = 3, maxnum = fitmax, objdat = objdat)
    
    # write feedme and constraints file
    comps = writefeedme(moddir = moddir, modfile = modfile, primary = primary, secondary = secondary)
    writeconstraints(moddir = moddir, modfile = modfile, primary = primary, secondary = secondary)
    
    # create mask image
    maskdat = segim.dat
    xvals = c(primary[,"X_IMAGE"],secondary[,"X_IMAGE"])
    yvals = c(primary[,"Y_IMAGE"],secondary[,"Y_IMAGE"])
    modvals = maskdat$dat[[1]][cbind(as.numeric(xvals),as.numeric(yvals))]
    if(any(modvals==0)){modvals = modvals[-which(modvals==0)]}
    if(any(modvals>0)){maskdat$dat[[1]][maskdat$dat[[1]]%in%modvals] = 0}
    write.fits(maskdat,file=primary[,"MSKIM"])

    # run GALFIT
    galcommand = paste(galfit, "-outsig -skyped", primary[,"SKYPED"], "-skyrms", primary[,"SKYRMS"], modfile)
    if(fulloutput){
        system(galcommand)
    }else{
        temp = suppressWarnings(system(galcommand, intern=TRUE))
    }
    
    # return data
    return(list(primary = primary, secondary = secondary, comps = comps))
    
}

# galfit #3 - jiggle fitting parameters
galfit3 = function(primary, moddir, modfile, objdat, fitaxis1, fitaxis2, fitxcen, fitycen, segim.dat, jiggle = "down"){
    
    # secondary data matrix
    secondary = trimsec(xlo = 1, xhi = fitaxis1, ylo = 1, yhi = fitaxis2, buffer = 3, maxnum = fitmax, objdat = objdat)
    
    # jiggle smaller
    if(jiggle == "down"){
        primary[,"MAG_AUTO"] = as.numeric(primary[,"MAG_AUTO"])+1
        primary[,"FLUX_RADIUS"] = as.numeric(primary[,"FLUX_RADIUS"])*0.9
        primary[,"SEXRE"] = as.numeric(primary[,"SEXRE"])*0.9
        if(length(secondary[,1])>0){
            secondary[,"MAG_AUTO"] = as.numeric(secondary[,"MAG_AUTO"])+1
            secondary[,"FLUX_RADIUS"] = as.numeric(secondary[,"FLUX_RADIUS"])*0.9
            secondary[,"SEXRE"] = as.numeric(secondary[,"SEXRE"])*0.9
        }
    }
    
    # jiggle larger/brighter
    if(jiggle == "up"){
        primary[,"MAG_AUTO"] = as.numeric(primary[,"MAG_AUTO"])-1
        primary[,"FLUX_RADIUS"] = as.numeric(primary[,"FLUX_RADIUS"])*1.1
        primary[,"SEXRE"] = as.numeric(primary[,"SEXRE"])*1.1
        if(length(secondary[,1])>0){
            secondary[,"MAG_AUTO"] = as.numeric(secondary[,"MAG_AUTO"])-1
            secondary[,"FLUX_RADIUS"] = as.numeric(secondary[,"FLUX_RADIUS"])*1.1
            secondary[,"SEXRE"] = as.numeric(secondary[,"SEXRE"])*1.1
        }
    }
    
    # write feedme and constraints file
    comps = writefeedme(moddir = moddir, modfile = modfile, primary = primary, secondary = secondary)
    writeconstraints(moddir = moddir, modfile = modfile, primary = primary, secondary = secondary)
    
    # create mask image
    maskdat = segim.dat
    xvals = c(primary[,"X_IMAGE"],secondary[,"X_IMAGE"])
    yvals = c(primary[,"Y_IMAGE"],secondary[,"Y_IMAGE"])
    modvals = maskdat$dat[[1]][cbind(as.numeric(xvals),as.numeric(yvals))]
    if(any(modvals==0)){modvals = modvals[-which(modvals==0)]}
    if(any(modvals>0)){maskdat$dat[[1]][maskdat$dat[[1]]%in%modvals] = 0}
    write.fits(maskdat,file=primary[,"MSKIM"])
    
    # run GALFIT
    galcommand = paste(galfit, "-outsig -skyped", primary[,"SKYPED"], "-skyrms", primary[,"SKYRMS"], modfile)
    if(fulloutput){
        system(galcommand)
    }else{
        temp = suppressWarnings(system(galcommand, intern=TRUE))
    }
    
    # return number of components
    return(list(primary = primary, secondary = secondary, comps = comps))
    
}

# galfit #4 - mask all secondaries
galfit4 = function(primary, moddir, modfile, objdat, fitaxis1, fitaxis2, fitxcen, fitycen, segim.dat){
    
    # secondary data matrix
    secondary = trimsec(xlo = 1, xhi = fitaxis1, ylo = 1, yhi = fitaxis2, buffer = 3, maxnum = 0, objdat = objdat)
    
    # write feedme and constraints file
    comps = writefeedme(moddir = moddir, modfile = modfile, primary = primary, secondary = secondary)
    writeconstraints(moddir = moddir, modfile = modfile, primary = primary, secondary = secondary)
    
    # create mask image
    maskdat = segim.dat
    xvals = c(primary[,"X_IMAGE"],secondary[,"X_IMAGE"])
    yvals = c(primary[,"Y_IMAGE"],secondary[,"Y_IMAGE"])
    modvals = maskdat$dat[[1]][cbind(as.numeric(xvals),as.numeric(yvals))]
    if(any(modvals==0)){modvals = modvals[-which(modvals==0)]}
    if(any(modvals>0)){maskdat$dat[[1]][maskdat$dat[[1]]%in%modvals] = 0}
    write.fits(maskdat,file=primary[,"MSKIM"])
    
    # run GALFIT
    galcommand = paste(galfit, "-outsig -skyped", primary[,"SKYPED"], "-skyrms", primary[,"SKYRMS"], modfile)
    if(fulloutput){
        system(galcommand)
    }else{
        temp = suppressWarnings(system(galcommand, intern=TRUE))
    }
    
    # return number of components
    return(list(primary = primary, secondary = secondary, comps = comps))
    
}

# galfit #5 - no constraints
galfit5 = function(primary, moddir, modfile, objdat, fitaxis1, fitaxis2, fitxcen, fitycen, segim.dat){
    
    # secondary data matrix
    secondary = trimsec(xlo = 1, xhi = fitaxis1, ylo = 1, yhi = fitaxis2, buffer = 3, maxnum = fitmax, objdat = objdat)
    
    # remove constraints
    unlink(primary[,"CONSTRAINTS"])
    primary[,"CONSTRAINTS"] = "none"
    
    # write feedme and constraints file
    comps = writefeedme(moddir = moddir, modfile = modfile, primary = primary, secondary = secondary)
    
    # create mask image
    maskdat = segim.dat
    xvals = c(primary[,"X_IMAGE"],secondary[,"X_IMAGE"])
    yvals = c(primary[,"Y_IMAGE"],secondary[,"Y_IMAGE"])
    modvals = maskdat$dat[[1]][cbind(as.numeric(xvals),as.numeric(yvals))]
    if(any(modvals==0)){modvals = modvals[-which(modvals==0)]}
    if(any(modvals>0)){maskdat$dat[[1]][maskdat$dat[[1]]%in%modvals] = 0}
    write.fits(maskdat,file=primary[,"MSKIM"])
    
    # run GALFIT
    galcommand = paste(galfit, "-outsig -skyped", primary[,"SKYPED"], "-skyrms", primary[,"SKYRMS"], modfile)
    if(fulloutput){
        system(galcommand)
    }else{
        temp = suppressWarnings(system(galcommand, intern=TRUE))
    }
    
    # return number of components
    return(list(primary = primary, secondary = secondary, comps = comps))
    
}

# trim secondary input list
trimsec = function(xlo, xhi, ylo, yhi, buffer = 3, maxnum = fitmax, objdat){
    
    # trim input object data
    secondary = as.matrix(objdat[
        (objdat[,"X_IMAGE"]) > (xlo+buffer)
        & (objdat[,"X_IMAGE"]) < (xhi-buffer)
        & (objdat[,"Y_IMAGE"]) > (ylo+buffer)
        & (objdat[,"Y_IMAGE"]) < (yhi-buffer)
    ,])
    if(dim(secondary)[2]==1){secondary=t(secondary)}
    if(length(secondary[,1])>maxnum & maxnum>0){
        secondary = secondary[order(secondary[,"PIXSEP"]),][1:maxnum,,drop=FALSE]
    }else if(length(secondary[,1])>maxnum & maxnum==0){
        secondary = secondary[0,]
    }
    
    # return results
    return(secondary)
    
}

# write a GALFIT feedme file
writefeedme = function(moddir, modfile, primary, secondary, addsky=TRUE, width=27){
    
    # read model file
    feedfile = readLines(paste(moddir,"/",modfile,sep=""))
    
    # components
    prilines = grep(" 0) ", feedfile)
    trnlines = grep("T0) ", feedfile)
    complines = sort(c(prilines,trnlines))
    pricomps = which(complines %in% prilines)
    trncomps = which(complines %in% trnlines)
    basenum = length(pricomps) + length(trncomps)
    if(length(secondary[,1])>0){
        seccomps = basenum + (1:length(secondary[,1]))
    }else{
        seccomps = NULL
    }
    
    # construct non-parsed feedme file
    filenum = rep(0,length(feedfile))
    o = 0
    if(length(secondary[,1])>0){
        for(o in 1:length(secondary[,1])){
            if(secondary[o,"CLASS_STAR"]>0.8){
                temp = readLines(paste(moddir,"/extras/secondary_psf.feedme",sep=""))
                feedfile = c(feedfile,temp)
            }else{
                temp = readLines(paste(moddir,"/extras/secondary_sersic.feedme",sep=""))
                feedfile = c(feedfile,temp)
            }
            filenum = c(filenum, rep(o,length(temp)))
        }
    }
    if(addsky){
        temp = readLines(paste(moddir,"/extras/sky.feedme",sep=""))
        feedfile = c(feedfile,temp)
        filenum = c(filenum, rep(o+1,length(temp)))
    }
    
    # remove print instructions
    if(strsplit(strsplit(feedfile[1]," +")[[1]],"")[[1]][1]=="#"){
        feedfile = feedfile[-1]
        filenum = filenum[-1]
    }
    
    # parse feedme file
    lines = grep("<<",feedfile)
    for(l in lines){
        if(filenum[l]>0 & filenum[l]<=length(secondary[,1])){
            # secondary
            repdat = t(as.matrix(secondary[filenum[l],]))
            repdat = cbind(repdat, CNUM=(filenum[l] + basenum))
        }else if(filenum[l]>0){
            # sky
            repdat = cbind(primary, CNUM=(filenum[l] + basenum))
        }else{
            # primary
            repdat = primary
        }
        feedfile[l] = parseline(inpline=feedfile[l], repdat=repdat)
    }
    
    # comment beautify
    lines = grep("#\\+",feedfile)
    for(l in lines){
        temp = strsplit(feedfile[l],"#\\+")[[1]]
        tdat = paste(strsplit(temp[1]," +")[[1]], collapse=" ")
        tcmt = temp[2]
        if(nchar(tdat)<width){
            temp = paste(tdat,paste(rep(" ",((width-nchar(tdat))-1)),collapse="",sep="")," #",tcmt,sep="")
        }else{
            temp = paste(tdat,tcmt,sep=" #")
        }
        feedfile[l] = temp
    }
    
    # write feedme
    cat(paste(feedfile, "\n", sep=""), rep("=",80), "\n\n", sep="", file=modfile)
    
    # return
    return(list(pricomps=pricomps, trncomps=trncomps, seccomps=seccomps))
    
}

# write a GALFIT constraints file
writeconstraints = function(moddir, modfile, primary, secondary){
    
    # check constraints file is not "none"
    if(primary[,"CONSTRAINTS"]!="none"){
        
        # construct non-parsed constraints file
        feedme = readLines(modfile)
        constfile = readLines(paste(moddir,"/",strsplit(modfile,".feedme")[[1]],".constraints",sep=""))
        filenum = rep(0,length(constfile))
        if(length(secondary[,1])>0){
            
            lcomp = grep("- Secondary ",feedme)+1
            for(p in 1:length(lcomp)){
                temp = strsplit(feedme[lcomp[p]]," +")[[1]]
                fittype = temp[grep("0)",temp)+1]
                temp = readLines(paste(moddir,"/extras/secondary_",fittype,".constraints",sep=""))
                if(any(temp=="")){temp = temp[-which(temp=="")]}
                constfile = c(constfile, temp)
                filenum = c(filenum, rep(p,length(temp)))
            }
            
            # detect total number of primaries
            feedfile = readLines(paste(moddir,"/",modfile,sep=""))
            complines = grep("# Component number:",feedfile)
            pricomps = 1:length(complines)
            npri = length(pricomps)
            constfile[filenum>0] = paste((filenum[filenum>0]+npri),constfile[filenum>0])
            
        }
        
        # parse constraints file
        lines = grep("<<",constfile)
        for(l in lines){
            if(filenum[l]>0){
                repdat = t(as.matrix(secondary[filenum[l],]))
            }else{
                repdat = primary
            }
            constfile[l] = parseline(inpline=constfile[l], repdat=repdat)
        }
        
        # write constraints file
        cat(paste(constfile, "\n", sep=""),"\n", sep="", file=primary[,"CONSTRAINTS"])
        
    }
    
}

# parse a SIGMA-GALFIT input feedme line
parseline = function(inpline, repdat, prefix="", suffix="", start="<<", end=">>", maxchar=8){
    
    # locate all parseable text in line
    starts = strsplit(inpline, start)[[1]]
    ends = grep(end, starts)
    
    for(m in ends){
        
        # separate (multiple) parseable values
        mids = strsplit(starts[m],end)[[1]]
        amid = strsplit(mids[1]," +")[[1]]
        if(any(amid=="")){amid=amid[-which(amid=="")]}
        
        # add prefix and suffix
        amid = paste(prefix,amid,suffix,sep="")
        
        # find and replace parseable values
        for(n in 1:length(amid)){
            if(tolower(amid[n])%in%tolower(colnames(repdat))){
                amid[n] = repdat[1,which(tolower(colnames(repdat))==tolower(amid[n]))]
            }
        }
        
        # parse
        if(length(amid)>1){
            amid = eval(parse(text=paste(amid,sep="",collapse="")))
        }
        
        # digit limitation
        if(maxchar>=0){
            if(!is.na(suppressWarnings(as.numeric(amid)))){
                if(nchar(amid)>maxchar){
                    digits = maxchar - nchar(round(as.numeric(amid))) - 1
                    if(digits < 0){digits = 0}
                    amid = formatC(as.numeric(amid), digits=digits, format="f")
                }
            }
        }
        
        # update section of line
        if(length(mids)>1){apad = mids[2:length(mids)]}else{apad = ""}
        starts[m] = paste(amid, apad, sep="")
        
    }
    
    # return parsed line
    return(paste(starts,collapse=""))
    
}

