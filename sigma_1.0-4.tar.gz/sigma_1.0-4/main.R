#!/usr/bin/Rscript --no-init-file
# SIGMA main script
# Written by Lee Kelvin

# version
vnum        = "1.0-3"
vdate       = "24 Feb 2014"

# main functions
source(paste(sigmadir,"/functions.R",sep=""))

# parse user inputs
inputfile = paste(sigmadir,"/input",sep="")
inputargs = commandArgs(TRUE)
inputdat = parseuserinputs(inputfile, inputargs)
if(gama1 | gama2){gama=TRUE}else{gama=FALSE}

# SIGMA version/help/defaults
sigmainfo(inputdat, version, help, defaults, vnum, vdate)

# SIGMA test
if(sigmatest){
    if(!file.exists("sigmatest")){system("mkdir sigmatest")}
    setwd("sigmatest")
    indir = outdir = getwd()
    setupbase = c("config", "configs", "models", "EXAMPLE/*")
    setupfiles = paste(sigmadir, setupbase, sep="/")
    for(i in 1:length(setupbase)){
        if(!file.exists(setupbase[i])){
            system(paste("cp -R", setupfiles[i], outdir))
        }
    }
    inputcat = "inputcat.csv"
    makeplot = TRUE
    band = "ri"
}

# directory setup
dirsetup(sigmadir, outdir, setup)

# directory check
dircheck(indir, outdir)

# simulated catalogue setup
simout = simsetup(inputcat, band, simra, simdec, simmag, simre, simindex, simellip, simdir, simim, simband, simmult, simulate)
inputcat = simout$inputcat
indir = simout$indir
band = simout$band

# Print Welcome
cat("\n----- SIGMA v",vnum," (",vdate,") @ ", date(), "\n",sep="")

# multiple processes
multiproc(subproc, subsamp, screen, session, sigmadir, append, inputcat)

# catalogue setup
dat = catsetup(catname, inputcat, sigmadir, gamaid, gallist, subsamp, gama, gama1, gama2, band)

# gamasetup
dat = gamasetup(band, surveys, dat, gama, simulate, indir, noweight)

# configuration file locations
nnw         = paste(outdir,"/configs/nnw.sex",sep="")           # Source Extractor NNW
skyconfig   = paste(outdir,"/configs/sky_config.sex",sep="")    # skysub: Source Extractor config
skyparam    = paste(outdir,"/configs/sky_param.sex",sep="")     # skysub: Source Extractor param
psfconfig   = paste(outdir,"/configs/psf_config.sex",sep="")    # psfest: Source Extractor config
psfparam    = paste(outdir,"/configs/psf_param.sex",sep="")     # psfext: Source Extractor param
psfexconfig = paste(outdir,"/configs/psf_config.psfex",sep="")  # psfext: PSFEx config
detconfig   = paste(outdir,"/configs/", grep("det_config", dir(paste(outdir,"/configs",sep="")), value=T), sep="")  # object: Source Extractor config
detparam    = paste(outdir,"/configs/det_param.sex",sep="")     # object: Source Extractor param
moddir      = paste(outdir,"/models",sep="")                    # fitter: GALFIT config directory

# Gaussian convolution kernels
gausscheck = c(skyconfig, psfconfig, detconfig)
for(i in 1:length(gausscheck)){
    gcheck = gausscheck[i]
    gaussbase = strsplit(strsplit(gcheck, ".sex")[[1]],"/")[[1]]
    gaussconv = paste(gaussbase[length(gaussbase)],".conv",sep="")
    confdat = readLines(gausscheck[i])
    gline = grep("# GAUSS FWHM PIX", confdat, value=T)
    if(length(gline)>0){
        FWHM = as.numeric(paste(strsplit(gline, "# GAUSS FWHM PIX")[[1]], collapse=""))
    }else{
        FWHM = 3
    }
    size = (FWHM*4)-1
    convkern =  rbind(formatC(gauss2d(size=size, FWHM=FWHM, norm=TRUE),format="f",digits=6,width=-9), rep("\n",size))
    #convkern = rbind(c(0.006319,0.040599,0.075183,0.040599,0.006319),c(0.040599,0.260856,0.483068,0.260856,0.040599),c(0.075183,0.483068,0.894573,0.483068,0.075183),c(0.040599,0.260856,0.483068,0.260856,0.040599),c(0.006319,0.040599,0.075183,0.040599,0.006319), rep("\n",5))
    cat("CONV NORM\n", convkern, file=gaussconv, sep=" ")
}

# reference time to give an ETA of finishing
timestart = proc.time()[3]

i = 1

# loop over each galaxy
for(i in 1:length(dat[,1])){
    
    # info
    timebegin = proc.time()[3]
    
    # bands
    band = strsplit(dat[i,"BAND"], " ")[[1]]
    
    # PSF FWHM
    if(gama & !simulate){
        hdrfwhm[2:(length(band)+1)] = gamafwhm[which(gamabands%in%band)]
    }
    if(length(hdrfwhm) != (length(band)+1)){
        base = hdrfwhm[2:length(hdrfwhm)]
        new = rep(base, ceiling(length(band)/length(base)))[1:length(band)]
        hdrfwhm[2:(length(band)+1)] = new
    }
    
    # setup
    setwd(outdir)
    galdat = dat[i,]
    galname = galdat[,"GALNAME"]
    galdir = paste(outdir, "/", galname, sep="")
    firstcol = length(galdat[1,])+1
    cutrad = as.numeric(cutrad)
    headinfo(i, length(dat[,1]), timestart, timebegin, galname, paste(band,collapse=""))
    
    # create galaxy folder
    if(file.exists(galdir)){system(paste("rm -R",galdir))}
    dir.create(galdir)
    setwd(galdir)
    
    # create sub-folders
    for(j in 1:length(band)){
        if(!file.exists(band[j])){
            dir.create(band[j])
        }
    }
    
    # cutter
    dgain = {}
    cat("----- cutter : ")
    for(j in 1:length(band)){
        cat(band[j])
        setwd(band[j])
        cutout = cutter(bandnum = j, galdat)
        galdat = cutout$galdat
        dgain = c(dgain, cutout$gain)
        setwd(galdir)
    }; cat(" : dgain =", paste(formatC(as.numeric(dgain), format="f", digits=1), collapse=" "), "\n\n")
    
    # background subtraction and sky estimation
    cat("----- skyest : ")
    for(j in 1:length(band)){
        cat(band[j])
        setwd(band[j])
        galdat = skyest(bandnum = j, galdat)
        setwd(galdir)
    }; cat(" : bgsub =", paste(formatC(as.numeric(strsplit(as.character(galdat[,"BACKFLUX"]), " ")[[1]]), format="f", digits=1), log(as.numeric(strsplit(as.character(galdat[,"BACKSIZE"]), " ")[[1]]), b=2), sep="/"), "\n\n")
    
    # psf estimation
    cat("----- psfest : ")
    for(j in 1:length(band)){
        cat(band[j])
        setwd(band[j])
        galdat = psfest(bandnum = j, galdat)
        setwd(galdir)
    }; cat(" : nstar =", galdat[,"PSFNUM"], "\n\n")
    
    # simulate
    if(simulate){
        cat("----- simgal : ")
        for(j in 1:length(band)){
            cat(band[j])
            setwd(band[j])
            galdat = simgal(bandnum = j, galdat)
            setwd(galdir)
        }; cat(" : mrnep =", galdat[,"SIMMAG"], galdat[,"SIMRE"], galdat[,"SIMINDEX"], galdat[,"SIMELLIP"], "0", "\n\n")
        
        # switch cutim and simim columns
        cutim = galdat[,"CUTIM"]
        simim = galdat[,"SIMIM"]
        galdat[,"CUTIM"] = simim
        galdat[,"SIMIM"] = cutim
    }
    
    # object detection
    objlist = {}
    cat("----- detect : ")
    for(j in 1:length(band)){
        cat(band[j])
        setwd(band[j])
        detout = detect(bandnum = j, galdat)
        galdat = detout$galdat
        objlist = c(objlist, list(detout$objlist))
        setwd(galdir)
    }; cat(" : detPS =", paste(strsplit(as.character(galdat[,"NPRI"])," ")[[1]], strsplit(as.character(galdat[,"NSEC"])," ")[[1]], sep=":"), "\n\n")
    
    # galaxy fitter
    galdatfull = galdat
    for(j in 1:length(band)){
        cat("----- fitter : ", band[j], sep="")
        setwd(band[j])
        galout = fitter(bandnum = j, galdat, galdatfull, objlist)
        galdat = galout$galdat
        galdatfull = galout$galdatfull
        setwd(galdir)
        cat("\n")
    }
    
    # simulation report
    if(simulate){
        for(j in 1:length(band)){
            cat("----- simrep : ", band[j], sep="")
            modids = strsplit(strsplit(galdat[,"MODID"], " ")[[1]][j], ",")[[1]]
            mtots = {}
            for(k in 1:length(modids)){
                modid = modids[k]
                mtot = as.numeric(strsplit(as.character(galdat[,paste(modid,"_GALMAGTOT",sep="")]), " ")[[1]][j])
                mtots = c(mtots, formatC(mtot, format="f", digits=2))
            }
            mtots = paste(mtots, collapse=" ")
            cat(" : tmags =", mtots, "\n\n")
        }
    }
    
    # analysis plot setup
    if(makeplot){cat("----- analim : ")}
    for(j in 1:length(band)){
        if(makeplot){cat(band[j])}
        setwd(band[j])
        analim(bandnum = j, galdat = galdatfull)
        setwd(galdir)
    }; if(makeplot){cat(" : analysis image(s) created!\n\n")}
    
    # clean up files
    if(junk){
        for(j in 1:length(band)){
            
            setwd(band[j])
            
            badcols = c("CUTIM", "CUTWT", "FITIM", "FITWT", "PSFCT", "PSFWT", "PSFWS", "PSFSS", "PSFSR", "OBJCT", "SEGIM", "SIMIM")
            for(k in 1:length(badcols)){
                if(badcols[k] %in% colnames(galdat)){
                    badcolnum = which(colnames(galdat)==badcols[k])
                    badfile = strsplit(as.character(galdat[,badcolnum]), " ")[[1]][j]
                    if(file.exists(as.character(badfile))){
                        unlink(badfile)
                    }
                }
            }
            
            unlink("sigma.fits")
            if(simulate){
                bad = grep(".fits", dir(), val=TRUE)
                unlink(bad)
            }
            
            setwd(galdir)
            
        }
    }
    
    # remove unwanted columns from galdat
    combpixsizes = galdat[,"PIXSIZE"]
    bad = c("BAND", "CUTIM", "CUTWT", "PIXSIZE", "INPXCEN", "INPYCEN", "CUTXCEN", "CUTYCEN", "CUTRADPIX", "MAGZP", "CUTAXIS1", "CUTAXIS2", "PSFWS", "PSFWT", "PSFCT", "PSFIM", "PSFSS", "PSFSR", "FITIM", "FITWT", "OBJCT", "SEGIM", "FITAXIS1", "FITAXIS2", "FITXCEN", "FITYCEN", "MODID", "MODIM", "MSKIM")
    if(length(grep("INPIM", colnames(galdat))) > 1){
        bad = c(bad, "INPIM")
    }
    if("SURVEY" %in% colnames(galdat)){
        bad = c(bad, "SURVEY")
    }
    galdat = galdat[,-which(colnames(galdat) %in% bad)]
    
    # split up bands
    if(band[1] != "."){
        
        bad = {}
        
        for(j in 1:length(galdat[1,])){
            
            cname = colnames(galdat)[j]
            cvals = strsplit(as.character(galdat[,j]), " ")[[1]]
            
            if(!cname %in% colnames(dat)){
                
                bname = paste(cname, band, sep="_")
                bvals = rbind(galdat[0], cvals)
                colnames(bvals) = bname
                galdat = cbind(galdat, bvals)
                bad = c(bad, j)
                
            }
            
        }
        
        if(length(bad) > 0){
            galdat = galdat[,-bad]
        }
        
    }
    
    # convert pixel sizes to arcsec
    pixsizes = as.numeric(strsplit(as.character(combpixsizes), " ")[[1]])
    pixcols = c("FLUX_RADIUS", "KRON_RADIUS", "SEXRE", "GALRE_", "GALINNERBREAK_", "GALINNERSOFT_", "GALOUTERBREAK_", "GALOUTERSOFT_", "GALREERR", "GALINNERBREAKERR", "GALINNERSOFTERR", "GALOUTERBREAKERR", "GALOUTERSOFTERR")
    for(k in 1:length(pixcols)){
        
        # identify all columns
        pixcol = pixcols[k]
        pixcolnums = grep(pixcol, colnames(galdat))
        pixcolnames = colnames(galdat)[pixcolnums]
        
        # loop over each identified column
        if(length(pixcolnames) > 0){
            
            for(j in 1:length(pixcolnames)){
                
                # identify passband
                pixcolnum = pixcolnums[j]
                pixcolname = pixcolnames[j]
                bandend = strsplit(pixcolname, "_")[[1]][length(strsplit(pixcolname, "_")[[1]])]
                
                # identify appropriate pixel scale
                if(bandend %in% band){
                    
                    pixsize = pixsizes[which(band==bandend)]
                    
                }else{
                    
                    pixsize = pixsizes[1]
                    
                }
                
                # update value
                galdat[,pixcolnum] = as.numeric(galdat[,pixcolnum]) * pixsize
                
            }
            
        }
        
    }
    
    # tar galaxy folder
    setwd(outdir)
    if(tarball){
        tarcommand = paste("tar -czf ", galname, ".tar.gz ", galname, sep="")
        system(tarcommand)
        unlink(galname, recursive=TRUE)
    }
    
    # add galdat to catalogue
    galcat = paste(catname,append,sep="")
    if(!file.exists(galcat) & !onlydata){
        cat(paste(colnames(galdat),collapse=","),"\n",sep="",file=galcat)
    }
    cat(paste(as.character(galdat),collapse=','),"\n",sep="",append=TRUE,file=galcat)
    
    # info
    timeend = proc.time()[3]
    tailinfo(i, length(dat[,1]), timestart, timebegin, timeend, galname, band)
    
}

# finish SIGMA
timefinish = proc.time()[3]
endinfo(length(dat[,1]), timestart, timefinish, band)

# finish multi-SIGMA
if(file.exists("sigmamultiproc.temp")){
    
    # read multi-proc file
    multicountfile = scan(file="sigmamultiproc.temp",quiet=TRUE)
    multicountnum = multicountfile[1] + 1
    multicounttot = multicountfile[2]
    multicountapp = multicountfile[3]
    if(is.na(multicountapp)){multicountapp=""}
    
    # last processor?
    if(multicountnum!=multicounttot){
        
        # update multiproc file
        cat(multicountnum, "\n", multicounttot, "\n", multicountapp, file="sigmamultiproc.temp", sep="")
        
        # sleep for a few seconds, to allow user to read end info
        Sys.sleep(3)
        
    }else if(multicountnum==multicounttot){
        
        # create catalogues and summary files cat lists
        concatcatlist = {}
        concatscrlist = {}
        for(i in 1:multicounttot){
            concatcatlist = paste(concatcatlist,catname,multicountapp,".",formatC(i,width=2,flag=0)," ",sep="")
            concatscrlist = paste(concatscrlist,"screenlog.",i," ",sep="")
        }
        
        # clean up
        convs = grep(".conv", dir(), value=TRUE)
        unlink(c("sigmamultiproc.temp", convs))
        
        # sleep for a few seconds, to allow user to read end info
        Sys.sleep(10)
        
        # join files
        unlink("screenlog")
        system(paste("cat ", concatcatlist, ">> ", catname, multicountapp, sep=""))
        system(paste("cat ", concatscrlist, ">> screenlog", sep=""))
        
        # move old sub files
        unlink("subfiles", recursive=TRUE)
        system("mkdir subfiles")
        system(paste("mv ", concatcatlist, " subfiles", sep=""))
        system(paste("mv ", concatscrlist, " subfiles", sep=""))
        system("mv screenlog.0 subfiles")
        
    }
    
}else{
    
    # clean up
    convs = grep(".conv", dir(), value=TRUE)
    unlink(c(convs))
    
}

# collect simulations together
if(simulate & file.exists(catname)){
    
    simclose()
    
}

#stop("\n\nStopped by Lee\n\n")








