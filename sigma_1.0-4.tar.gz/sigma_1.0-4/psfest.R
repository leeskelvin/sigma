#!/usr/bin/Rscript --no-init-file
# SIGMA (Structural Investigation of Galaxies via Model Analysis) model generator
# Written by Lee Kelvin

# psf estimation
psfest = function(bandnum = 1, galdat){
    
    if(psf[1]=="NA"){
        
        # input definitions
        cutim = strsplit(galdat[,"CUTIM"], " ")[[1]][bandnum]
        cutwt = strsplit(galdat[,"CUTWT"], " ")[[1]][bandnum]
        cutxcen = as.numeric(strsplit(as.character(galdat[,"CUTXCEN"]), " ")[[1]][bandnum])
        cutycen = as.numeric(strsplit(as.character(galdat[,"CUTYCEN"]), " ")[[1]][bandnum])
        pixsize = as.numeric(strsplit(as.character(galdat[,"PIXSIZE"]), " ")[[1]][bandnum])
        zp = as.numeric(strsplit(as.character(galdat[,"MAGZP"]), " ")[[1]][bandnum])
        cutaxis1 = as.numeric(strsplit(as.character(galdat[,"CUTAXIS1"]), " ")[[1]][bandnum])
        cutaxis2 = as.numeric(strsplit(as.character(galdat[,"CUTAXIS2"]), " ")[[1]][bandnum])
        cutradpix = as.numeric(strsplit(as.character(galdat[,"CUTRADPIX"]), " ")[[1]][bandnum])
        gauss = paste(outdir, "/psf_config.conv", sep="")
        
        # output definitions
        psfbase = strsplit(cutim,"cutim")[[1]][2]
        psfws = paste("psfws",psfbase,sep="")
        psfwt = paste("psfwt",psfbase,sep="")
        psfct = paste("psfct",psfbase,sep="")
        psfim = paste("psfim",psfbase,sep="")
        psfss = paste("psfss",psfbase,sep="")
        psfsr = paste("psfsr",psfbase,sep="")
        
        if(cutwt!="NA"){
            
            # select stars from similar weight image only
            cutwt.dat = read.fitsim(cutwt)
            cutwt.dat = signif(cutwt.dat, digits=2)
            cutwt.dat.bak = cutwt.dat
            testcounts = goodcounts = cutwt.dat[cutxcen,cutycen]
            cutwtunique = unique(as.numeric(cutwt.dat))
            
            # if more than 1 frame makes up the cutout image
            if(length(cutwtunique)>1){
                
                # mondrian manoeuvre - clever minimisation of cutwt.dat to speed up finding algorithm
                tempdat1 = as.matrix(cutwt.dat[,1])
                for(i in 1:(length(cutwt.dat[,1])-1) ){
                    if( FALSE%in%(cutwt.dat[,i]==cutwt.dat[,i+1]) ){
                        tempdat1 = cbind(tempdat1,cutwt.dat[,i+1])
                    }
                }
                tempdat2 = as.matrix(tempdat1[1,])
                for(i in 1:(length(tempdat1[,1])-1) ){
                    if( FALSE%in%(tempdat1[i,]==tempdat1[i+1,]) ){
                        tempdat2 = cbind(tempdat2,as.matrix(tempdat1[i+1,]))
                    }
                }
                cutwt.dat = t(tempdat2)
                
                # calculate contributing frames
                while(length(testcounts)>0){
                    partcounts = {}
                    for(i in 1:length(testcounts)){
                        pos = which(cutwt.dat==testcounts[i],arr.ind=TRUE)
                        # 1 pix wobble
                        pos = rbind(
                            cbind((pos[,1]-1),(pos[,2]-0)), # left
                            cbind((pos[,1]+0),(pos[,2]+1)), # up
                            cbind((pos[,1]+1),(pos[,2]+0)), # right
                            cbind((pos[,1]+0),(pos[,2]-1)) # down
                        )
                        # remove outer edge for 1 pix wobble
                        if(any(pos==0)){pos = rbind(pos[-which(pos==0,arr.ind=T)[,1],])}
                        if(any(pos[,1]==(dim(cutwt.dat)[1]+1))){pos = rbind(pos[-which(pos[,1]==(dim(cutwt.dat)[1]+1)),])}
                        if(any(pos[,2]==(dim(cutwt.dat)[2]+1))){pos = rbind(pos[-which(pos[,2]==(dim(cutwt.dat)[2]+1)),])}
                        # pick out weight values to be used
                        tempcounts = unique(cutwt.dat[pos])
                        partcounts = c(partcounts, tempcounts[which(tempcounts<testcounts[i] & !tempcounts%in%goodcounts)])
                        goodcounts = c(goodcounts, partcounts)
                    }
                    testcounts = partcounts
                }
                
            }else{
                cutwt.dat = matrix(cutwtunique,1,1)
            }
            
            # pick out master weight values to be used (values must go downhill and share a border)
            write.fits(cutwt.dat, file=psfws)
            cutwt.dat = cutwt.dat.bak
            cutwt.dat[!cutwt.dat%in%goodcounts] = 0
            
        }else{
            
            # create fake psfwt file
            cutwt.dat = matrix(1,cutaxis1,cutaxis2)
            
        }
        
        # mask central area (equal to 5% of axis cutout length) to ensure primary is not used to generate PSF
        maskrad = ceiling(0.025*cutradpix)
        maskxlo = max((cutxcen-maskrad), 1)
        maskxhi = min((cutxcen+maskrad), cutaxis1)
        maskylo = max((cutycen-maskrad), 1)
        maskyhi = min((cutycen+maskrad), cutaxis2)
        cutwt.dat[maskxlo:maskxhi,maskylo:maskyhi] = 0
        
        # write out star weight map
        write.fits(cutwt.dat, file=psfwt)
        
        # source extract
        arglist = list(WEIGHT_TYPE = "MAP_WEIGHT", WEIGHT_IMAGE = psfwt, STARNNW_NAME = nnw, CATALOG_NAME = psfct, CATALOG_TYPE = "FITS_LDAC", MAG_ZEROPOINT = zp, PIXEL_SCALE = pixsize, BACK_TYPE = "MANUAL", BACK_VALUE = 0, FILTER_NAME = gauss)
        sexcommand = buildsex(sex, cutim, psfconfig, psfparam, arglist)
        output = system(sexcommand, intern=TRUE)
        
        # SEx output
        linenum1 = grep('Measuring from:', output)
        linenum2 = grep('Background:', output)
        linenum3 = grep('Objects: detected', output)
        results1 = strsplit(output[linenum1], " +")
        results2 = strsplit(output[linenum2], " +")
        results3 = strsplit(output[linenum3], " +")
        anchor = which(results1[[1]]=='FLOATING')
        xdim = results1[[1]][anchor-6]                                                # X-dimension
        ydim = results1[[1]][anchor-4]                                                # Y-dimension
        #sky = results2[[1]][3]                                                        # Sky mean level
        #skyRMS = results2[[1]][5]                                                     # Sky RMS
        thresh = results2[[1]][8]                                                     # Threshold for detection
        sextracted = results3[[1]][6]                                                 # Objects source extracted
        sextotal = results3[[1]][3]                                                   # Total potential objects
        #deltasky = as.numeric(skyRMS)/sqrt(0.90*as.numeric(xdim)*as.numeric(ydim))    # Error on sky mean
        
        # PSF Extract
        psfexcommand = paste(psfex, psfct, "-c" , psfexconfig, "-PSFVAR_NSNAP 1 2>&1")
        output = system(psfexcommand, intern=TRUE)
        
        # PSFEx output
        linenum = grep('Saving CHECK-image #1', output) - 1
        results = strsplit(output[linenum], " +")
        psfaccept = strsplit(results[[1]][2], "/", fixed=T)[[1]][1]
        psftotal = strsplit(results[[1]][2], "/", fixed=T)[[1]][2]
        psfsamp = results[[1]][3]
        psfchi2 = results[[1]][4]
        psffwhmpix = results[[1]][5]
        psffwhm = as.numeric(psffwhmpix)*pixsize
        psfellip = results[[1]][6]
        psfresid = results[[1]][7]
        psfasym = results[[1]][8]
        
        # tidy up folder
        file.rename(paste("snap_", psfct, sep=""), psfim)   # PSF image
        file.rename(paste("samp_", psfct, sep=""), psfss)   # PSF star sample
        file.rename(paste("resi_", psfct, sep=""), psfsr)   # PSF star residuals
        file.remove(paste("chi_", psfct, sep=""))
        file.remove(paste("proto_", psfct, sep=""))
        file.remove(paste(strsplit(psfct,".fit")[[1]][1],".psf",sep=""))
        
        # generate Gaussian PSF if no suitable stars found
        if(as.numeric(psfaccept)==0){
            size = as.numeric(read.fitskey("NAXIS1",psfim))
            psffwhm = as.numeric(read.fitskey("PSFFWHM",cutim))
            psffwhmpix = psffwhm/pixsize
            psfchi2 = null
            write.fits(moffat2d(size = size, FWHM = psffwhmpix, n=3), psfim)
        }
        
    }else{
        
        # setups
        psfim = psf[1]
        psffwhm = as.numeric(psf[2])
        psfws = psfwt = psfct = psfss = psfsr = psfaccept = psfchi2 = null
        
        # file path check
        if(!file.exists(psfim)){
            posspsfim = paste(outdir,"/",psfim,sep="")
            if(file.exists(posspsfim)){
                psfim = posspsfim
            }else{
                cat("\n  Error: Could not find user-specified PSF image. Specify full path!\n\n")
                quit(save="no")
            }
        }
        
    }
    
    # update results
    extras = galdat[0]
    checklist = list(PSFWS=psfws, PSFWT=psfwt, PSFCT=psfct, PSFIM=psfim, PSFSS=psfss, PSFSR=psfsr, PSFNUM=psfaccept, PSFCHI2=psfchi2, PSFFWHM=psffwhm)
    for(i in 1:length(checklist)){
        
        if(names(checklist)[i]%in%colnames(galdat)){
            col = which(colnames(galdat)==names(checklist)[i])[1]
            galdat[,col] = paste(galdat[,col], checklist[[i]])
        }else{
            extras = cbind(extras, checklist[[i]])
            colnames(extras)[length(colnames(extras))] = names(checklist)[i]
        }
        
    }
    
    # return results
    galdat = cbind(galdat, extras, stringsAsFactors=FALSE)
    return(galdat)
    
}

