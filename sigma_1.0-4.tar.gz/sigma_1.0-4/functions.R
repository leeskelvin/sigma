#!/usr/bin/Rscript --no-init-file
# SIGMA common functions
# Written by Lee Kelvin

# parse user inputs
parseuserinputs = function(inputfile, inputargs){

    # read inputfile
    inputdat = read.table(inputfile, skip=4, colClasses="character", header=TRUE)
    
    # detect user inputs
    if(any(inputdat[,"inp"]%in%inputargs)){
        for(i in which(inputdat[,"inp"]%in%inputargs)){
            j = which(inputargs%in%inputdat[i,"inp"])
            if(as.numeric(inputdat[i,"req"])==0){
                inputdat[i,"arg"] = as.logical((as.logical(inputdat[i,"arg"])+1)%%2)
            }else if(as.numeric(inputdat[i,"req"])>0){
                inputdat[i,"arg"] = paste(inputargs[(j+1):(j+as.numeric(inputdat[i,"req"]))], collapse=" ")
            }
        }
    }
    
    # assign parsed input commands
    for(i in 1:length(inputdat[,1])){
        if(as.numeric(inputdat[i,"req"])>0){
            inputdat[i,"arg"] = paste("c(",paste(paste("'",strsplit(inputdat[i,"arg"]," +")[[1]],"'",sep=""),collapse=",",sep=""), ")", sep="")
        }
        assign(inputdat[i,"cmd"],eval(parse(text = inputdat[i,"arg"])), pos=".GlobalEnv")
    }
    
    # return parsed input file
    return(inputdat)
    
}

# SIGMA version/help/defaults
sigmainfo = function(inputdat, version, help, defaults, vnum, vdate){
    
    # version
    if(version){
        cat("\n----- SIGMA Version ",vnum," -- ",vdate,"\n\n",sep="")
        quit(save="no")
    }
    
    # help
    if(help){
        cat("\n----- SIGMA Version ",vnum," -- ",vdate,"\n
DESCRIPTION
    SIGMA (Structural Investigation of Galaxies via Model Analysis) is a 2 
    dimensional fitting code taking inputs from the GAMA SWarped regions and
    producing models using the GALFIT software.

SETUP
    Before running SIGMA, make sure to copy the SIGMA setup files and 
    directories into your current working directory using the '-s' argument. 
    A typical input catalogue should contain at least 3 columns: 
      RA       (right ascension)
      DEC      (declination)
      INPIM    (input image)
    For GAMA runs, INPIM should not be required, use the '-gama' flags instead. 
    Two further optional columns may also be specified: 
      GALNAME  (galaxy name identifier)
      INPWT    (input weight map)

OPTIONS
", paste("   ",formatC(inputdat[,"inp"],width=-3),formatC(inputdat[,"def1"],width=-4),inputdat[,"def2"],"\n"), "
CONTACT
    Lee Kelvin
    University of Innsbruck, Austria
    lee.kelvin@uibk.ac.at
\n",sep="")
        quit(save="no")
    }
    
    # defaults
    if(defaults){
        
        # read software versions
        if(file.exists("config")){conffile = "config"}else{conffile = paste(sigmadir,"/config",sep="")}
        source(conffile)
        galfitversion = system(paste(galfit, "-help"), intern=TRUE)
        galfitversion = grep("GALFIT Version", galfitversion, value=TRUE)
        require("astro", quietly=TRUE)
        require("astroextras", quietly=TRUE)
        
        # print
        cat("\n----- SIGMA Version ",vnum," -- ",vdate,"

SOFTWARE VERSIONS
    astro       (R PKG) astro version ",sessionInfo()$otherPkgs$astro$Version, " (",sessionInfo()$otherPkgs$astro$Date,")
    astroextras (R PKG) astroextras version ",sessionInfo()$otherPkgs$astroextras$Version," (",sessionInfo()$otherPkgs$astroextras$Date,")
    SExtractor  (", sex, ") ", system(paste(sex,'-v'),intern=TRUE), "
    PSFEx       (", psfex, ") ", system(paste(psfex,'-v'),intern=TRUE), "
    GALFIT      (", galfit, ") ", galfitversion, "

DEFAULTS
", paste("   ",formatC(inputdat[,"inp"],width=-3),formatC(inputdat[,"cmd"],width=-(max(nchar(inputdat[,"cmd"]))+0)),inputdat[,"arg"],"\n"), "
",sep="")
        quit(save="no")
    }
    
}

# directory setup
dirsetup = function(sigmadir, outdir, setup){
    
    # copy SIGMA config files and directories
    if(setup){
        system(paste("cp -R ", sigmadir, "/config ", outdir, sep=""))
        system(paste("cp -R ", sigmadir, "/configs ", outdir, sep=""))
        system(paste("cp -R ", sigmadir, "/models ", outdir, sep=""))
        cat("\n  SIGMA: Configuration files copied to local directory.\n         Please check and edit these files before running SIGMA.\n\n")
        quit(save="no")
    }
    
    # check SIGMA config files and directories exist
    c1 = file.exists(paste(outdir,"/config",sep=""))
    c2 = file.exists(paste(outdir,"/configs",sep=""))
    c3 = file.exists(paste(outdir,"/models",sep=""))
    if(!c1 | !c2 | !c3){
        cat("\n  Error: Please run sigma -s to configure this directory for SIGMA first\n\n")
        quit(save="no")
    }
    source(paste(outdir,"/config",sep=""))
    
    # source required scripts and load required libraries
    require("astro", quietly=TRUE)
    require("astroextras", quietly=TRUE)
    source(paste(sigmadir,"/cutter.R",sep=""))
    source(paste(sigmadir,"/skyest.R",sep=""))
    source(paste(sigmadir,"/psfest.R",sep=""))
    source(paste(sigmadir,"/simgal.R",sep=""))
    source(paste(sigmadir,"/detect.R",sep=""))
    source(paste(sigmadir,"/fitter.R",sep=""))
    source(paste(sigmadir,"/analim.R",sep=""))
    
}

# directory check
dircheck = function(indir, outdir){
    
    # check input (data) directory
    if(!file.exists(indir)){
        cat("\n  ERROR: Input directory '", indir, "' not found!\n\n", sep="")
        quit(save="no")
    }
    
    # check output directory
    if(!file.exists(outdir)){
        dir.create(outdir,recursive=TRUE)
    }
    setwd(outdir)
    
}

# multiple processes
multiproc = function(subproc, subsamp, screen, session, sigmadir, append, inputcat){
    
    # setup
    subproc = as.numeric(subproc)
    #subsamp = as.numeric(subsamp)
    subsamp = c(eval(parse(text=subsamp[1])), eval(parse(text=subsamp[2])))
    
    # if multiple sub-processes
    if(subproc > 0){
        
        # master screen
        system(paste(screen, " -dmLS ", session, " -t SIGMA -c ", sigmadir, "/screenrc", sep=""))
        
        # catalogue fractions
        #subprocfrac = (subsamp[2]-subsamp[1])/subproc
        #newsubsamps = seq(subsamp[1],subsamp[2],subprocfrac)
        newsubsamps = paste(seq(subsamp[1], subsamp[2], length=subproc+1) * subproc, "/", subproc, sep="")
        
        # multi-processor log file
        if(subproc > 1){cat("0\n",subproc,"\n",append,sep="",file="sigmamultiproc.temp")}
        
        # setup each processor on a sub-screen
        for(i in 1:subproc){
            
            # filter input args for protected keywords
            subargs = inputargs
            if(inputdat[which(inputdat[,"cmd"]=="append"),"inp"] %in% subargs){
                subargs[which(subargs == inputdat[which(inputdat[,"cmd"]=="append"),"inp"])+1] = paste(append, ".", formatC(i,width=2,flag=0), sep="")
            }else{
                subargs = c(subargs, inputdat[which(inputdat[,"cmd"]=="append"),"inp"], paste(append, ".", formatC(i,width=2,flag=0), sep=""))
            }
            if(inputdat[which(inputdat[,"cmd"]=="inputcat"),"inp"] %in% subargs){
                subargs[which(subargs == inputdat[which(inputdat[,"cmd"]=="inputcat"),"inp"])+1] = inputcat
            }else{
                subargs = c(subargs, inputdat[which(inputdat[,"cmd"]=="inputcat"),"inp"], inputcat)
            }
            if(inputdat[which(inputdat[,"cmd"]=="subproc"),"inp"] %in% subargs){
                subargs[which(subargs == inputdat[which(inputdat[,"cmd"]=="subproc"),"inp"])+1] = "0"
            }else{
                subargs = c(subargs, inputdat[which(inputdat[,"cmd"]=="subproc"),"inp"], "0")
            }
            if(inputdat[which(inputdat[,"cmd"]=="subsamp"),"inp"] %in% subargs){
                subargs[which(subargs == inputdat[which(inputdat[,"cmd"]=="subsamp"),"inp"])+(1:2)] = c(as.character(newsubsamps[i]), as.character(newsubsamps[i+1]))
            }else{
                subargs = c(subargs, inputdat[which(inputdat[,"cmd"]=="subsamp"),"inp"], c(as.character(newsubsamps[i]), as.character(newsubsamps[i+1])))
            }
            if(i>1){
                if(!inputdat[which(inputdat[,"cmd"]=="onlydata"),"inp"] %in% subargs){
                    subargs = c(subargs, inputdat[which(inputdat[,"cmd"]=="onlydata"),"inp"])
                }else{
                    subargs = c(subargs, inputdat[which(inputdat[,"cmd"]=="onlydata"),"inp"])
                }
            }
            
            # construct and run multi-processor screen command
            multicommand = paste(screen, " -S ", session, " -X screen -t p", formatC(i,width=2,flag=0), " ", sigmadir, "/sigma ", paste(subargs, collapse=" "), sep="")
            system(multicommand)
            
        }
        
        # end of the road for the master script
        cat("
     TNMMMMMMMMMMMMMMMMMMMMMMMMMM       
         YMMMMM                MM       SIGMA started successfully!
         ,MMMMM                 M       
         ,MMMMMMMMMMMMMMMMMMMMMMN       Monitor its progress by typing:
         ,MMMMMMMMM            MMR      
         ,MMMMM WMMMN            M      screen -r ",session,"
         ,MMMMM  WMMMMN          N      
         ,MMMMM    WMMMN                
         ,MMMMM      WMMMN              
         ,MMMMM       MMMV              
         ,MMMMM       MV                
         ,MMMMM     MV                  
         ,MMMMM   MV              M     
         :MMMMM MM              ZMM     
         MMMMMMMMMMMMMMMMMMMMMMMMMY     This terminal may now be closed safely
     MMMMMMMMMMMMMMMMMMMMMMMMMMMMM      
                                        
\n", sep="")
        quit(save="no")
    }
    
}

# catalogue setup
catsetup = function(catname, inputcat, sigmadir, gamaid, gallist, subsamp, gama, gama1, gama2, band){
    
    # check for existing catalogue
    if(file.exists(catname)){
        file.rename(catname,paste(catname,".old",sep=""))
    }
    
    # GAMA specific catalogue
    if(gama1){gamacat = "tiling16"}
    if(gama2){gamacat = "tiling42"}
    if(gama){
        if(!file.exists(inputcat)){
            inputcat = paste(sigmadir, "/", gamacat, ".img", sep="")
        }
    }
    
    # read in input catalogue
    options(stringsAsFactors = FALSE)
    if(file.exists(inputcat)){
        
        # catalogue extension
        catext = substring(inputcat,nchar(inputcat)-3)
        
        # catalogue loader
        if(catext == ".img"){
            load(inputcat)
        }else if(catext == ".csv"){
            dat = read.csv(inputcat)
        }else{
            dat = read.table(inputcat)
            temp = readLines(inputcat)
            if(strsplit(temp," +")[[1]][1]=="#"){
                colnames(dat)=strsplit(temp," +")[[1]][1:length(dat[1,])+1]
            }
        }
        
    }else{
        
        # unable to find catalogue
        cat("\n  ERROR: Input catalogue '", inputcat, "' not found!\n\n", sep="")
        quit(save="no")
        
    }
    
    # a GAMA run?
    if(gama & !simulate){
        
        # individual GAMA ID
        if(gamaid!="NA"){
            
            # GAMA ID
            gamaidnum = suppressWarnings(as.numeric(gamaid))
            
            # locate GAMA ID in GAMA catalogue
            if(length(which(dat[,"CATAID"]==gamaidnum))>0){
                
                dat = dat[which(dat[,"CATAID"]==gamaidnum),]
                
            }else{
                
                cat("\n  ERROR: Could not find GAMA ID '", gamaid, "'\n\n", sep="")
                quit(save="no")
                
            }
        
        # galaxy sub-list
        }else if(gallist!="NA"){
            
            if(file.exists(gallist)){
                
                # list extension
                listext = substring(gallist,nchar(gallist)-3)
                
                # load galaxy sub-list
                if(listext == ".csv"){
                    samp = read.csv(gallist)
                }else{
                    samp = read.table(gallist)
                    temp = readLines(gallist)
                    if(strsplit(temp," +")[[1]][1]=="#"){
                        colnames(samp)=strsplit(temp," +")[[1]][1:length(samp[1,])+1]
                    }
                }
                
                # locate GAMA CATAID column (default = 1)
                catcol = 1
                if("CATAID"%in%colnames(samp)){
                    catcol = which(colnames(samp)=="CATAID")
                }
                if(any(samp[,catcol]%in%dat[,"CATAID"])){
                    dat = dat[which(dat[,"CATAID"]%in%samp[,catcol]),]
                }else{
                    cat("\n  ERROR: No matching CATAID's found in input catalogue\n\n")
                    quit(save="no")
                }
                
            }else{
                
                cat("\n  ERROR: Galaxy list '", gallist, "' not found!\n\n", sep="")
                quit(save="no")
                
            }
            
        }
        
    # a normal run
    }else{
        
        # multiple bands (non-GAMA)
        if(!"INPIM" %in% colnames(dat)){
            
            # pick out INPIM columns
            inpcols = grep("INPIM",colnames(dat))
            
            if(length(inpcols) > 0){
                
                temp = dat[,inpcols[1]]
                
                if(length(inpcols) > 1){
                    
                    for(i in 2:length(inpcols)){
                        
                        temp = paste(temp, dat[,inpcols[i]], sep=" ")
                        
                    }
                    
                }
                
                # add INPIM column to main catalogue
                dat = cbind(dat, INPIM = temp)
                
            }else{
                
                cat("\n  ERROR: no input image columns (INPIM) found in input catalogue!\n\n", sep="")
                quit(save="no")
                
            }
            
        }
        
        # band column
        if(band!="NA"){
            band = strsplit(band,"")[[1]]
        }else{
            numbands = 1:length(strsplit(dat[1,"INPIM"], " ")[[1]])
            if(length(numbands)>1){
                band = toupper(letters[numbands])
            }else{
                band = "."
            }
        }
        dat[,"BAND"] = paste(band, collapse=" ")
        
    }
    
    # galaxy name column
    if("GALNAME"%in%colnames(dat)){
        NULL
    }else if("CATAID"%in%colnames(dat)){
        dat = cbind(dat, GALNAME = paste("G",dat[,"CATAID"],sep=""), stringsAsFactors=FALSE)
    }else{
        dat = cbind(dat, GALNAME = paste("S",(1:length(dat[,1])),sep=""), stringsAsFactors=FALSE)
    }
    
    # sub-samples
    subsamp = c(eval(parse(text=subsamp[1])), eval(parse(text=subsamp[2])))
    if(subsamp[1]!=0 | subsamp[2]!=1){
        
        q = quantile((1:(length(dat[,1])+1)), subsamp)
        lowersub = floor(q[1])
        uppersub = floor(q[2])-1
        dat = dat[lowersub:uppersub,]
        
    }
    
    # return catalogue data
    return(dat)
    
}

# gamasetup
gamasetup = function(band, surveys, dat, gama, simulate, indir, noweight){
    
    if(gama & !simulate){
        
        # input file name format
        gamaim = function(survey, band, region){
            imname = paste("swpim_", survey, "_", band, "_", region, ".fits", sep="")
            return(imname)
        }
        gamawt = function(survey, band, region){
            wtname = paste("swpwt_", survey, "_", band, "_", region, ".fits", sep="")
            return(wtname)
        }
        
        # bands
        allbands = "ugrizYJHK"
        if(band=="."){
            
            # have not specified a GAMA band
            cat("\n  ERROR: This is a GAMA run - please specify a band! [a = ", allbands, "]\n\n", sep="")
            quit(save="no")
            
        }
        if(band=="a"){band = allbands}
        band = strsplit(band,"")[[1]]
        
        # survey
        surveys = strsplit(surveys,"")[[1]]
        bands = gamabands
        codes = rbind(
            c("s", "sdss"),
            c("k", "kids"),
            c("u", "ukidss"),
            c("v", "viking"),
            c("2", "2mass")
        )
        lookups = list(
            u = c("sdss", "kids"),
            g = c("sdss", "kids"),
            r = c("sdss", "kids"),
            i = c("sdss", "kids"),
            z = c("sdss"),
            Z = c("viking"),
            Y = c("ukidss", "viking"),
            J = c("ukidss", "viking", "2mass"),
            H = c("ukidss", "viking", "2mass"),
            K = c("ukidss", "viking", "2mass")
        )
        
        # region
        region = rep("", length(dat[,1]))
        if(any(dat[,"RA"]>000 & dat[,"RA"]<050)){region[which(dat[,"RA"]>000 & dat[,"RA"]<050)] = "g02"}
        if(any(dat[,"RA"]>100 & dat[,"RA"]<150)){region[which(dat[,"RA"]>100 & dat[,"RA"]<150)] = "g09"}
        if(any(dat[,"RA"]>150 & dat[,"RA"]<200)){region[which(dat[,"RA"]>150 & dat[,"RA"]<200)] = "g12"}
        if(any(dat[,"RA"]>200 & dat[,"RA"]<250)){region[which(dat[,"RA"]>200 & dat[,"RA"]<250)] = "g15"}
        if(any(dat[,"RA"]>300 & dat[,"RA"]<360)){region[which(dat[,"RA"]>300 & dat[,"RA"]<360)] = "g23"}
        
        # loop over each band to determine survey
        surveycolumn = {}
        for(j in 1:length(band)){
            
            # possibles
            temp = data.frame()
            poss = lookups[[which(band[j]==names(lookups))]]
            poss = rbind(temp, codes[which(codes[,2]%in%poss),])
            
            # loop over each survey type
            ordered = {}
            for(k in 1:length(surveys)){
                if(tolower(surveys[k])%in%tolower(poss[,1])){
                    ordered = rbind(ordered,poss[which(tolower(poss[,1])==tolower(surveys[k])),])
                }
            }
            
            # determine input image/weight file names
            survey = ordered[1,2]
            surveycolumn = c(surveycolumn, survey)
            inpims = gamaim(survey, band[j], region)
            inpwts = gamawt(survey, band[j], region)
            if(j == 1){
                inpim = inpims
                inpwt = inpwts
            }else{
                inpim = paste(inpim, inpims)
                inpwt = paste(inpwt, inpwts)
            }
            
        }
        
        # test weight image
        weight = paste(indir,"/",inpwts[1],sep="")
        
        # update INPIM/INPWT column
        dat[,"INPIM"] = inpim
        if(file.exists(weight[1])){
            if(!noweight){
                dat[,"INPWT"] = inpwt
            }
        }
        dat[,"SURVEY"] = paste(surveycolumn, collapse=" ")
        dat[,"BAND"] = paste(band, collapse=" ")
        
    }
    
    # return data
    return(dat)
    
}

## nicetime, convert seconds to a nice string time
#nicetime = function(seconds){
#    # Converts seconds to a string (# days, # hours, # minutes, # seconds)
#    lapseconds = round(seconds)
#    seconds = lapseconds%%60
#    minutes = ((lapseconds - seconds)/60)%%60
#    hours = ((lapseconds - minutes*60 - seconds)/3600)%%24
#    days = ((lapseconds - hours*3600 - minutes*60 - seconds)/86400)
#    lapline={}
#    if(days!=0){
#        if(days==1){lapline=paste(days,"d, ",sep="")   # day
#        }else{lapline=paste(days,"d, ",sep="")         # days
#        }
#    }
#    if(hours!=0 | days!=0){
#        if(hours==1){lapline=paste(lapline,hours,"h, ",sep="")     # hour
#        }else{lapline=paste(lapline,hours,"h, ",sep="")            # hours
#        }
#    }
#    if(minutes!=0 | hours!=0 | days!=0){
#        if(minutes==1){lapline=paste(lapline,minutes,"m, ",sep="")     # minute
#        }else{lapline=paste(lapline,minutes,"m, ",sep="")              # minutes
#        }
#    }
#    if(seconds==1){lapline=paste(lapline,seconds,"s",sep="")           # second
#    }else{lapline=paste(lapline,seconds,"s",sep="")                    # seconds
#    }
#    return(lapline)
#}

# headinfo, writes useful header information (position in run, and ETA left)
headinfo = function(i, length, timestart, timebegin, name, band, timefact = 1.1){
    if(i>1){
        eta = paste(" ETA:",nicetime(round(timefact*((timebegin-timestart)/(i-1))*(length-(i-1)))),"=====")
    }else{
        eta=""
    }
    if(band=="NA"){
        info = paste("===== ",i," / ",length," : ",name, " ",sep="")
    }else{
        info = paste("===== ",i," / ",length," : ",name," : ",band, " ",sep="")
    }
    filllength = (80-nchar(eta))-nchar(info)
    if(filllength<0){filllength=0}
    filler = paste(rep("=", filllength),collapse="")
    cat("\n",info,filler,eta,"\n\n",sep="")
}

# tailinfo, writes useful tail information (time taken)
tailinfo = function(i, length, timestart, timebegin, timeend, name, band){
    timetaken = paste(" Time: ",nicetime(round(timeend-timebegin)),", Avg:", nicetime(round((timeend-timestart)/(i)))," -----", sep="")
    info = paste("----- ",i," / ",length," : ",name," : ",paste(band,collapse=""), " ",sep="")
    filllength = (80-nchar(timetaken))-nchar(info)
    if(filllength<0){filllength=0}
    filler = paste(rep("-", filllength),collapse="")
    cat("",info,filler,timetaken,"\n",sep="")
}

# endinfo, SIGMA finish information
endinfo = function(length, timestart, timefinish, band){
    if(length==1){
        galaxytext = "1 galaxy"
    }else{
        galaxytext = paste(length, "galaxies")
    }
    if(band[1] == "."){
        bandtext = ""
    }else if(length(band)==1){
        bandtext = paste(" in the ", band, "-band", sep="")
    }else{
        bandtext = paste(" across ", length(band), " bands", sep="")
    }
    cat("\n", rep("=",80), "\n\n----- SIGMA Complete!\n\n***** ", galaxytext, bandtext, " modelled in ", nicetime(round(timefinish-timestart)), " (Avg: ", nicetime(round(timefinish-timestart)/length), ")\n\n", sep="")
}

# gauss2d, creates an arbitrary 2D Gaussian
gauss2d = function(size = 5, FWHM = 2, norm = TRUE){
    x = y = (((size+1)/2)-size):(size-((size+1)/2))
    xy = expand.grid(x,y)
    r = sqrt((xy[,1]^2) + (xy[,2]^2))
    sigma = FWHM / (2*(sqrt(2*log(2))))
    g = exp(-(r^2) / (2*(sigma^2)))
    if(norm){g = g / sum(g)}
    mat = matrix(g, length(x), length(y))
    return(mat)
}

# moffat2d
moffat2d = function(size = 5, FWHM = 2, n = 2, norm = TRUE){
    x = y = (((size+1)/2)-size):(size-((size+1)/2))
    xy = expand.grid(x,y)
    r = sqrt((xy[,1]^2) + (xy[,2]^2))
    rd = FWHM / (2*sqrt((2^(1/n))-1))
    m = 1 / ((1 + ((r/rd)^2))^n)
    if(norm){m = m / sum(m)}
    mat = matrix(m, length(x), length(y))
    return(mat)
}

# source extractor command line builder
buildsex = function(sex, inputimage, configfile, paramfile, arglist){
    
    sexcommand = paste(sex, inputimage, "-c", configfile, "-PARAMETERS_NAME", paramfile)
    for(i in 1:length(arglist)){
        sexcommand = paste(sexcommand, paste("-",names(arglist)[i]," ",arglist[[i]],sep=""))
    }
    sexcommand = paste(sexcommand, "2>&1")
    return(sexcommand)
    
}

# cnames, provides the column names for a Source Extractor ASCII_HEAD file
cnames = function(file){
    tabinfo = grep("#",readLines(file),value=T)
    cnames = {}
    for(l in 1:length(tabinfo)){
        cnames = c(cnames, strsplit(tabinfo[l], " +")[[1]][3])
    }
    return(cnames)
}

# ellipse generator
ellipsematrix = function(xcen = 0, ycen = 0, a = 50, e = 0.5, theta = 0, xseq = -100:100, yseq = -100:100){
    
    # setup
    xy = expand.grid(xseq,yseq)
    b = a*(1-e)
    theta = -theta * (pi/180)
    
    # ellipse values
    e = ((((xy[,1]-xcen)*cos(theta) - (xy[,2]-ycen)*sin(theta))^2) / (a^2)) + ((((xy[,1]-xcen)*sin(theta) + (xy[,2]-ycen)*cos(theta))^2) / (b^2))
    e = matrix(e, length(xseq), length(yseq))
    
    # return ellipse values
    return(e)
    
}












## input setup
#setup = function(inputfile, inputargs){
#    
#    # setup
#    
#    
#    # write init file
#    finishoff = FALSE
#    if(file.exists(".init.sigma")){
#        temp = read.csv(file=".init.sigma", skip=1, stringsAsFactors=FALSE, header=FALSE)
#        if((temp[,1]==inputcat) & (temp[,2]==subproc) & (temp[,3]==band) & (temp[,4]==surveys)){
#            finishoff = TRUE
#        }
#    }
#    cat(finishoff,"\n",inputcat,",",subproc,",'",band,"','",surveys,"'\n", sep="", file=paste(".init.sigma",append,sep=""))
#    
#    
#    
#    # Source Extra files
#    #source(starfits)
#    
#    # Return catalogue
#    return(list(dat=dat))
#}

## begone, silently delete files if they exist
#begone = function(x=NULL){
#    if(!is.null(x[1])){
#        for(be in 1:length(x)){
#            if(file.exists(x[be])){
#                file.remove(x[be])
#            }
#        }
#    }
#}







## bandinfo, mid-step band info
#bandinfo = function(name, band, bands){
#    bands[which(bands==band)] = paste("[",band,"]",sep="")
#    info = paste("      ",name," : ",paste(bands,collapse=""), " ",sep="")
#    filllength = 80-nchar(info)
#    if(filllength<0){filllength=0}
#    filler = paste(rep("-", filllength),collapse="")
#    cat("",info,filler,"\n\n",sep="")
#}







## sigmaslide, create a script that creates a slideshow of (pre-made) profile images
#sigmaslide = function(){cat('#!/usr/bin/Rscript --no-init-file

## setup
#convert = "/usr/bin/convert"
#allbands = c("u","g","r","i","z","Y","J","H","K")

## files and folders
#files = grep(".png",dir(recursive=T),v=T)
#folders = dir()
#folders = folders[-which(!folders%in%allbands)]
#if(length(files)==0){
#    for(i in 1:length(folders)){
#        setwd(folders[i])
#        system("./sigmaplot.R")
#        setwd("..")
#    }
#}
#files = grep(".png",dir(recursive=T),v=T)
#bands = allbands[which(allbands%in%dir())]
#bandorder = match(allbands,folders)
#if(any(is.na(bandorder))){bandorder = bandorder[-which(is.na(bandorder))]}
#testband = bands[1]
#singleband = grep(paste(testband,"/",sep=""),files,v=T)
#idents = unlist(strsplit(grep("png",unlist(strsplit(singleband,"-")),v=T),".png"))
#galname = paste(strsplit(strsplit(singleband[1],"_")[[1]][1],paste(testband,"/",sep=""))[[1]],collapse="")

## make slideshow for each model type
#for(i in 1:length(idents)){
#    
#    # find model files
#    ifiles = grep(idents[i], files, v=T)[bandorder]
#    
#    # convert
#    cmd = paste(convert, " -delay 100 ", paste(ifiles, collapse=" "), " ", galname, "-", idents[i], ".gif", sep="")
#    system(cmd)
#    
#}

## make slideshow for a single band
#pband = "r"
#if(pband%in%bands){
#    
#    # find band files
#    ifiles = grep(paste(pband,"/",sep=""), files, v=T)
#    
#    # convert
#    cmd = paste(convert, " -delay 100 ", paste(ifiles, collapse=" "), " ", galname, "-", pband, ".gif", sep="")
#    system(cmd)
#    
#}

## make slideshow for a single band
#pband = "K"
#if(pband%in%bands){
#    
#    # find band files
#    ifiles = grep(paste(pband,"/",sep=""), files, v=T)
#    
#    # convert
#    cmd = paste(convert, " -delay 100 ", paste(ifiles, collapse=" "), " ", galname, "-", pband, ".gif", sep="")
#    system(cmd)
#    
#}

#', file="sigmaslide.R", sep="")
#    
#    # chmod
#    system("chmod uog+x sigmaslide.R")

#}











