#!/usr/bin/Rscript --no-init-file
# SIGMA (Structural Investigation of Galaxies via Model Analysis)
# Written by Lee Kelvin

# background subtraction and sky estimation
skyest = function(bandnum = 1, galdat){
    
    # definitions
    cutim = strsplit(galdat[,"CUTIM"], " ")[[1]][bandnum]
    cutwt = strsplit(galdat[,"CUTWT"], " ")[[1]][bandnum]
    cutxcen = as.numeric(strsplit(as.character(galdat[,"CUTXCEN"]), " ")[[1]][bandnum])
    cutycen = as.numeric(strsplit(as.character(galdat[,"CUTYCEN"]), " ")[[1]][bandnum])
    cutaxis1 = as.numeric(strsplit(as.character(galdat[,"CUTAXIS1"]), " ")[[1]][bandnum])
    cutaxis2 = as.numeric(strsplit(as.character(galdat[,"CUTAXIS2"]), " ")[[1]][bandnum])
    cutradpix = as.numeric(strsplit(as.character(galdat[,"CUTRADPIX"]), " ")[[1]][bandnum])
    pixsize = as.numeric(strsplit(as.character(galdat[,"PIXSIZE"]), " ")[[1]][bandnum])
    zp = as.numeric(strsplit(as.character(galdat[,"MAGZP"]), " ")[[1]][bandnum])
    gauss = paste(outdir, "/sky_config.conv", sep="")
    
    # central galaxy flux prior to background subtraction
    cenpix = paste(fitscopy," ",cutim,"[",format(cutxcen-1,scientific=FALSE),":",format(cutxcen+1,scientific=FALSE),",",format(cutycen-1,scientific=FALSE),":",format(cutycen+1,scientific=FALSE),"] cenflux.fits",sep="")
    system(cenpix)
    cenflux = sum(as.numeric(read.fitsim("cenflux.fits")))/9
    unlink("cenflux.fits")
    
    # main SExtractor arglist
    arglist = list(WEIGHT_TYPE = "NONE", WEIGHT_IMAGE = cutwt, STARNNW_NAME = nnw, CATALOG_NAME = "tempcat.dat", CATALOG_TYPE = "ASCII_HEAD", BACK_FILTERSIZE = 3, CHECKIMAGE_TYPE = "BACKGROUND", CHECKIMAGE_NAME = "tempcut.fits", MAG_ZEROPOINT = zp, PIXEL_SCALE = pixsize, FILTER_NAME = gauss, PHOT_FLUXFRAC=0.99)
    if(cutwt!="NA"){arglist$WEIGHT_TYPE = "MAP_WEIGHT"}
    
    # possible background mesh size values
    backvals = c(32, 64, 128, 256, 512)
    
    # 64 standard
    arglist$BACK_SIZE = 64
    sexcommand = buildsex(sex, cutim, skyconfig, skyparam, arglist)
    output = system(sexcommand, intern=TRUE)
    
    # calculate appropriate back size
    fluxdiam = 63
    if(file.exists(arglist$CATALOG_NAME)){
        if(length(readLines(arglist$CATALOG_NAME))>length(read.table(skyparam)[,1])){
            d = read.table(arglist$CATALOG_NAME)
            colnames(d) = cnames(arglist$CATALOG_NAME)
            pixsep = sqrt(((d[,"X_IMAGE"]-cutxcen)^2)+((d[,"Y_IMAGE"]-cutycen)^2))
            fluxdiam = 2*d[which.min(pixsep),"FLUX_RADIUS"]
        }
    }
    
    # determine appropriate back size
    if(fluxdiam>511){fluxdiam=511}
    backsize = backvals[which(((backvals-fluxdiam)[(backvals-fluxdiam)>0][1])==(backvals-fluxdiam))]
    if(file.exists(arglist$CATALOG_NAME)){file.remove(arglist$CATALOG_NAME)}
    
    # rerun with appropriate back size if needed
    if(backsize!=arglist$BACK_SIZE){
        arglist$BACK_SIZE = backsize
        sexcommand = buildsex(sex, cutim, skyconfig, skyparam, arglist)
        output = system(sexcommand, intern=TRUE)
    }
    
    # background statistics
    x = read.fitsim(arglist$CHECKIMAGE_NAME)
    backstats = quantile(x, c(pnorm(-1), 0.5, pnorm(1)))
    backsig = sd(as.numeric(x))
    backerr = as.numeric(backsig)/sqrt(0.90*as.numeric(cutaxis1)*as.numeric(cutaxis2))
    backflux = sum(x[(cutxcen-1):(cutxcen+1),(cutycen-1):(cutycen+1)])/9
    
#    # central background flux
#    cenpix = paste(fitscopy," tempcut.fits[",format(cutxcen-1,scientific=FALSE),":",format(cutxcen+1,scientific=FALSE),",",format(cutycen-1,scientific=FALSE),":",format(cutycen+1,scientific=FALSE),"] cenflux.fits",sep="")
#    system(cenpix)
#    backflux = sum(as.numeric(read.fitsim("cenflux.fits")))/9
#    unlink("cenflux.fits")
    
    # source extract for sky (identical command to above, except for CHECKIMAGE_TYPE)
    arglist$CHECKIMAGE_TYPE = "-OBJECTS"
    sexcommand = buildsex(sex, cutim, skyconfig, skyparam, arglist)
    output = system(sexcommand, intern=TRUE)
    
    # sky statistics
    x = read.fits(arglist$CHECKIMAGE_NAME)
    skystats = quantile(x$dat[[1]], c(pnorm(-1), 0.5, pnorm(1)))
    skysig = sd(as.numeric(x$dat[[1]]))
    skyerr = as.numeric(skysig)/sqrt(0.90*as.numeric(cutaxis1)*as.numeric(cutaxis2))
    #skyflux = sum(x$dat[[1]][(cutxcen-1):(cutxcen+1),(cutycen-1):(cutycen+1)])/9    # will always equal zero
    
    # GALFIT sky statistics setup
    y = imtrim(x$dat[[1]], xcen=cutxcen, ycen=cutycen, trim=cutradpix/10)
    x$dat[[1]] = y
    write.fits(x, file=arglist$CHECKIMAGE_NAME)
    primary = cbind(SKYIN=arglist$CHECKIMAGE_NAME, SKYOUT="tempgal.fits", XLO=1, XHI=cutaxis1, YLO=1, YHI=cutaxis2, ZP=zp, PIXSIZE=pixsize, SKYPED=0, SKYRMS=skysig)
    comps = writefeedme(moddir = paste(moddir,"/extras",sep=""), modfile = "skyest.feedme", primary = primary, secondary = NULL, addsky=FALSE)
    
    # run GALFIT
    galcommand = paste(galfit, "-skyped", primary[,"SKYPED"], "-skyrms", primary[,"SKYRMS"], "skyest.feedme")
    if(fulloutput){
        system(galcommand)
    }else{
        temp = suppressWarnings(system(galcommand, intern=TRUE))
    }
    
    # analyse GALFIT header output
    galres = strsplit(read.fitskey(key="1_SKY", file=primary[,"SKYOUT"], hdu=3), " +")[[1]]
    galskyped = strip(galres[1], c("["," ","*","]"))
    galskyerr = strip(galres[3], c("["," ","*","]"))
    
    # clean up GALFIT
    unlink(c("fit.log", "skyest.feedme", "galfit.01", primary[,"SKYIN"], primary[,"SKYOUT"]))
    
    # source extract for background subtracted image (identical command to above, except for CHECKIMAGE_TYPE)
    arglist$CHECKIMAGE_TYPE = "-BACKGROUND"
    sexcommand = buildsex(sex, cutim, skyconfig, skyparam, arglist)
    output = system(sexcommand, intern=TRUE)
    file.rename(arglist$CHECKIMAGE_NAME, cutim)
    
    # remove leftovers
    unlink("tempcat.dat")
    
    ## detected
    #detected = as.numeric(strsplit(grep('Objects: detected', output, value=TRUE)," +")[[1]][3])
    
    # update results
    extras = galdat[0]
    checklist = list(CENFLUX=cenflux, BACKSIZE=arglist$BACK_SIZE, BACKLO=backstats[1], BACKMED=backstats[2], BACKHI=backstats[3], BACKSD=backsig, BACKERR=backerr, BACKFLUX=backflux, SKYLO=skystats[1], SKYMED=skystats[2], SKYHI=skystats[3], SKYSD=skysig, SKYERR=skyerr, GALSKYPED=galskyped, GALSKYERR=galskyerr)
    for(i in 1:length(checklist)){
        
        if(names(checklist)[i]%in%colnames(galdat)){
            col = which(colnames(galdat)==names(checklist)[i])[1]
            galdat[,col] = paste(galdat[,col], checklist[[i]])
        }else{
            extras = cbind(extras, checklist[[i]])
            colnames(extras)[length(colnames(extras))] = names(checklist)[i]
        }
        
    }
    
    # return results
    galdat = cbind(galdat, extras, stringsAsFactors=FALSE)
    return(galdat)
    
}

