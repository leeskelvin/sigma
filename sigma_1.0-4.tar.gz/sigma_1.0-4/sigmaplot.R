#!/usr/bin/Rscript --no-init-file
# SIGMA (Structural Investigation of Galaxies via Model Analysis)
# Written by Lee Kelvin

# load astro
library(astro, quietly=TRUE)
library(astroextras, quietly=TRUE)

# postage stamp data
stampdat = read.fits("pstamp.fits")
hdr = stampdat$hdr[[1]]
modids = strsplit(hdr[which(hdr[,"key"] == "MODIDS"),"value"], ",")[[1]]
modims = paste(modids,"_objim.fits",sep="")

# 1D line profile colours
cols = c("red", "blue", "hotpink", "brown", "darkgreen")

# step size (arcseconds)
stepsize = 0.5

# create a trimmed image, with a border of zeroes if necessary
imtrim = function(input, xcen, ycen, trim = 50){
    
    # axes
    axis1 = dim(input)[1]
    axis2 = dim(input)[2]
    paxis1 = ((trim*2)+1)
    paxis2 = ((trim*2)+1)
    pxcen = trim + 1
    pycen = trim + 1
    xcen = round(xcen)
    ycen = round(ycen)
    
    # input limits
    xlo = max((round(xcen) - trim), 1)
    xhi = min((round(xcen) + trim), axis1)
    ylo = max((round(ycen) - trim), 1)
    yhi = min((round(ycen) + trim), axis2)
    
    # mapped limits
    pxlo = round((pxcen-xcen) + xlo)
    pxhi = round((pxcen-xcen) + xhi)
    pylo = round((pycen-ycen) + ylo)
    pyhi = round((pycen-ycen) + yhi)
    pdat = matrix(0, paxis1, paxis2)
    pdat[pxlo:pxhi,pylo:pyhi] = input[xlo:xhi,ylo:yhi]
    
    # return results
    return(pdat)
    
}

# loop over each modim
for(i in 1:length(modims)){
    
    # setup
    modid = modids[i]
    modim = modims[i]
    
    # pick out variables from header
    galname = as.character(hdr[which(hdr[,"key"]==paste(modid,"_GALNAME",sep="")),"value"])
    survey = as.character(hdr[which(hdr[,"key"]==paste(modid,"_SURVEY",sep="")),"value"])
    band = as.character(hdr[which(hdr[,"key"]==paste(modid,"_BAND",sep="")),"value"])
    modname = as.character(hdr[which(hdr[,"key"]==paste(modid,"_MODNAME",sep="")),"value"])
    mskim = as.character(hdr[which(hdr[,"key"]==paste(modid,"_MSKIM",sep="")),"value"])
    subim = as.character(hdr[which(hdr[,"key"]==paste(modid,"_SUBIM",sep="")),"value"])
    forcefit = as.logical(hdr[which(hdr[,"key"]==paste(modid,"_FORCEFIT",sep="")),"value"])
    pixsize = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_PIXSIZE",sep="")),"value"])
    fitxcen = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_FITXCEN",sep="")),"value"])
    fitycen = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_FITYCEN",sep="")),"value"])
    prfmag = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_PRFMAG",sep="")),"value"])
    prfmag10 = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_PRFMAG10",sep="")),"value"])
    prfre = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_PRFRE",sep="")),"value"])
    prfindex = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_PRFINDEX",sep="")),"value"])
    prfellip = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_PRFELLIP",sep="")),"value"])
    prfpa = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_PRFPA",sep="")),"value"])
    prfxoff = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_PRFXOFF",sep="")),"value"])
    prfyoff = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_PRFYOFF",sep="")),"value"])
    sky = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_SKY",sep="")),"value"])
    skyerr = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_SKYERR",sep="")),"value"])
    skyrms = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_SKYRMS",sep="")),"value"])
    zp = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_ZP",sep="")),"value"])
    gain = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_GAIN",sep="")),"value"])
    exptime = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_EXPTIME",sep="")),"value"])
    modxlo = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_MODXLO",sep="")),"value"])
    modxhi = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_MODXHI",sep="")),"value"])
    modylo = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_MODYLO",sep="")),"value"])
    modyhi = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_MODYHI",sep="")),"value"])
    modxoff = strsplit(as.character(hdr[which(hdr[,"key"]==paste(modid,"_MODXOFF",sep="")),"value"]),",")[[1]]
    modyoff = strsplit(as.character(hdr[which(hdr[,"key"]==paste(modid,"_MODYOFF",sep="")),"value"]),",")[[1]]
    modmag = strsplit(as.character(hdr[which(hdr[,"key"]==paste(modid,"_MODMAG",sep="")),"value"]),",")[[1]]
    modmag10 = strsplit(as.character(hdr[which(hdr[,"key"]==paste(modid,"_MODMAG10",sep="")),"value"]),",")[[1]]
    modre = strsplit(as.character(hdr[which(hdr[,"key"]==paste(modid,"_MODRE",sep="")),"value"]),",")[[1]]
    modindex = strsplit(as.character(hdr[which(hdr[,"key"]==paste(modid,"_MODINDEX",sep="")),"value"]),",")[[1]]
    modellip = strsplit(as.character(hdr[which(hdr[,"key"]==paste(modid,"_MODELLIP",sep="")),"value"]),",")[[1]]
    modpa = strsplit(as.character(hdr[which(hdr[,"key"]==paste(modid,"_MODPA",sep="")),"value"]),",")[[1]]
    modfrac = strsplit(as.character(hdr[which(hdr[,"key"]==paste(modid,"_MODF",sep="")),"value"]),",")[[1]]
    modfrac10 = strsplit(as.character(hdr[which(hdr[,"key"]==paste(modid,"_MODF10",sep="")),"value"]),",")[[1]]
    modmagtot = strsplit(as.character(hdr[which(hdr[,"key"]==paste(modid,"_MODMT",sep="")),"value"]),",")[[1]]
    modmag10tot = strsplit(as.character(hdr[which(hdr[,"key"]==paste(modid,"_MODM10T",sep="")),"value"]),",")[[1]]
    modgalchi2 = strsplit(as.character(hdr[which(hdr[,"key"]==paste(modid,"_MODGCHI2",sep="")),"value"]),",")[[1]]
    modprichi2 = strsplit(as.character(hdr[which(hdr[,"key"]==paste(modid,"_MODPCHI2",sep="")),"value"]),",")[[1]]
    modbic = strsplit(as.character(hdr[which(hdr[,"key"]==paste(modid,"_MODBIC",sep="")),"value"]),",")[[1]]
    
    # plotting definitions
    ptype = hdr[which(hdr[,"key"]==paste(modid,"_PTYPE",sep="")),"value"]
    pslide = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_PSLIDE",sep="")),"value"])
    pscale = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_PSCALE",sep="")),"value"])
    plo = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_PLO",sep="")),"value"])
    phi = as.numeric(hdr[which(hdr[,"key"]==paste(modid,"_PHI",sep="")),"value"])
    pinv = as.logical(hdr[which(hdr[,"key"]==paste(modid,"_PINV",sep="")),"value"])
    
    # image dimensions
    xdim = dim(stampdat$dat[[1]])[1]
    ydim = dim(stampdat$dat[[1]])[2]
    xcen = ycen = (xdim+1)/2
    trim = (xdim-1)/2
    
    # only continue if GALFIT output files exist
    if(file.exists(modim)){
        
        # read FITS images
        modimdat = read.fits(modim)
        subimdat = read.fits(subim)
        mskimdat = read.fits(mskim)
        
        # component numbers
        npri = length(modmag)
        nsec = length(subimdat$dat) - npri - 3
        prinum = 2 + (1:npri)
        if(nsec>0){
            secnum = (2 + npri) + (1:nsec)
        }else{
            secnum = NULL
        }
        
        # axes and centroids
        fitaxis1 = dim(mskimdat$dat[[1]])[1]
        fitaxis2 = dim(mskimdat$dat[[1]])[2]
        modaxis1 = dim(subimdat$dat[[1]])[1]
        modaxis2 = dim(subimdat$dat[[1]])[2]
        modxcen = which((1:fitaxis1)[modxlo:modxhi] == fitxcen) + prfxoff
        modycen = which((1:fitaxis2)[modylo:modyhi] == fitycen) + prfyoff
        fitxcen = which((1:fitaxis1)[modxlo:modxhi] == fitxcen)
        fitycen = which((1:fitaxis2)[modylo:modyhi] == fitycen)
        
        # primary model image
        primod = matrix(0, modaxis1, modaxis2)
        for(e in prinum){
            primod = primod+subimdat$dat[[e]]
        }
        
        # secondary model image
        secmod = matrix(0, modaxis1, modaxis2)
        if(length(secnum)>0){
            for(e in secnum){
                secmod = secmod+subimdat$dat[[e]]
            }
        }
        
        # master setup
        pridat = modimdat$dat[[2]] - secmod
        prires = modimdat$dat[[4]]
        mskdat = mskimdat$dat[[1]][modxlo:modxhi,modylo:modyhi]
        compdat = {}
        for(e in prinum){
            compdat = c(compdat, list(subimdat$dat[[e]]))
        }
        
        # master data array
        master = c(list(pridat, primod, prires), compdat)
        
        # calculate surface brightness light profiles
        maxrad = min(abs(c(((modxcen+1) - c(modxlo, modxhi)), ((modycen+1) - c(modylo, modyhi)))))
        sb = sbprof(master, hdu=1:length(master), mask=mskdat, mask.hdu=1, pa=prfpa, e=prfellip, pixsize=pixsize, step=stepsize/pixsize, cen=c(modxcen,modycen), minrad=0, maxrad=maxrad, sky=sky, skyerr=skyerr, skyrms=skyrms, zp=zp, gain=gain, exptime=exptime, iraf="cl")
        
        # image setups
        dat = imtrim(input=modimdat$dat[[2]], xcen=modxcen, ycen=modycen, trim=trim)
        mod = imtrim(input=modimdat$dat[[3]], xcen=modxcen, ycen=modycen, trim=trim)
        res = imtrim(input=modimdat$dat[[4]], xcen=modxcen, ycen=modycen, trim=trim)
        
    }else{
        
        # component numbers
        npri = length(modmag)
        
        # image setups
        mat = matrix(0, xdim, xdim)
        modxcen = modycen = xcen
        dat = stampdat$dat[[1]]
        mod = res = mat
        
    }
    
    if(file.exists(modim)){
        
        # segmentation setup
        plotxcen = (xdim+1) / 2 + prfxoff
        plotycen = (ydim+1) / 2 + prfyoff
        seg = imtrim(input=modimdat$dat[[1]], xcen=fitxcen, ycen=fitycen, trim=trim)
        msk = imtrim(input=mskdat, xcen=fitxcen, ycen=fitycen, trim=trim)
        priseg = seg[plotxcen,plotycen]
        seg[seg==priseg] = -1
        seg[seg>0] = 1
        msk[msk>0] = 1
        seg = seg+msk
        seg[seg==-1] = 3    # 0=background, 1=1D mask, 2=2D mask, 3=primary image
        
    }
    
    # plot
    if(band!="."){
        pngname = paste(galname, "_", band, "-", modid, ".png", sep="")
    }else{
        pngname = paste(galname, "-", modid, ".png", sep="")
    }
    png(file=pngname, width=8, height=4, units="in", res=200)
    layout(rbind(c(1,2,5),c(4,3,5),c(4,3,6)),heights=c(3,1,2),widths=c(1,1,2))
    par("mar"=c(0,0,0,0))
    
    # plotting values
    pfunc = ptype
    slide = pslide
    scale = pscale
    locut = plo
    hicut = phi
    invert = pinv
    labcex = 1
    
    # data
    pfdat = plotfits(dat, func = pfunc, slide = slide, scale = scale, locut = locut, hicut = hicut, invert = invert, type = "dat", xdim = xdim, ydim = ydim)
    image(1:dim(pfdat$mat)[1], 1:dim(pfdat$mat)[2], pfdat$mat, col = pfdat$col, asp = 1, axes = FALSE, xlab = "", ylab = "")
    label(pos = "topleft", txt = galname, whitespace = 0.1, col = "white", bgcol = acol("grey25",a=0.5), bty = "b", bordercol = "black", lwd = 0, cex = labcex, align = "center")
    if(survey==""){txt = band}else{txt = paste(survey,band)}
    label(pos = "topright", txt = txt, whitespace = 0.1, col = "white", bgcol = acol("grey25",a=0.5), bty = "b", bordercol = "black", lwd = 0, cex = labcex, align = "center")
    scalemark(pixsize = pixsize)
    if(!file.exists(modim) | forcefit){
        lines(c(xcen,xcen), c(ycen-5,ycen-15), lwd=2, col="white")
        lines(c(xcen,xcen), c(ycen+5,ycen+15), lwd=2, col="white")
        lines(c(xcen-5,xcen-15), c(ycen,ycen), lwd=2, col="white")
        lines(c(xcen+5,xcen+15), c(ycen,ycen), lwd=2, col="white")
    }
    
    # model
    pfmod = plotfits(mod, func = pfunc, slide = slide, scale = scale, locut = locut, hicut = hicut, invert = invert, type = "dat", xdim = xdim, ydim = ydim)
    image(1:dim(pfmod$mat)[1], 1:dim(pfmod$mat)[2], pfmod$mat, col = pfmod$col, asp = 1, axes = FALSE, xlab = "", ylab = "")
    label(pos = "topleft", txt = paste("Model:",modid,modname), whitespace = 0.1, col = "white", bgcol = acol("grey25",a=0.5), bty = "b", bordercol = "black", lwd = 0, cex = labcex, align = "center")
    
    # residual
    pfres = plotfits(res, func = pfunc, slide = slide, scale = scale, locut = locut, hicut = hicut, invert = invert, type = "dat", xdim = xdim, ydim = ydim)
    image(1:dim(pfres$mat)[1], 1:dim(pfres$mat)[2], pfres$mat, col = pfres$col, asp = 1, axes = FALSE, xlab = "", ylab = "")
    label(pos = "topleft", txt = "Residual", whitespace = 0.1, col = "white", bgcol = acol("grey25",a=0.5), bty = "b", bordercol = "black", lwd = 0, cex = labcex, align = "center")
    
    # detail
    if(file.exists(modim)){
        
        pfseg = plotfits(seg, func = "lin", slide = 0, scale = 1, locut = 0, hicut = 3, invert = FALSE, type = "dat", xdim = xdim, ydim = ydim)
        pfseg$col[which(pfseg$col=="#000000")] = acol("black", alpha=0)
        pfseg$col[which(pfseg$col=="#555555")] = acol("green3",a=0.5)
        pfseg$col[which(pfseg$col=="#AAAAAA")] = acol("orange",a=0.5)
        pfseg$col[which(pfseg$col=="#FFFFFF")] = acol("purple",a=0.25)
        image(1:dim(pfdat$mat)[1], 1:dim(pfdat$mat)[2], pfdat$mat, col = pfdat$col, asp = 1, axes = FALSE, xlab = "", ylab = "")
        image(1:dim(pfseg$mat)[1], 1:dim(pfseg$mat)[2], pfseg$mat, col = pfseg$col, asp = 1, axes = FALSE, xlab = "", ylab = "", add = TRUE)
        
        # ellipses
        steps = 5   # ellipse steps
        elty = 1    # ellipse line type
        lines(ellipse(xcen=plotxcen, ycen=plotycen, a=prfre/pixsize, e=prfellip, pa=prfpa), col="orange", lwd=3)
        if(abs(npri)>1){
            for(v in 1:abs(npri)){
                cre = as.numeric(modre[v])
                cellip = as.numeric(modellip[v])
                cpa = as.numeric(modpa[v])
                lines(ellipse(xcen=plotxcen, ycen=plotycen, a=cre/pixsize, e=cellip, pa=cpa), col=cols[v], lwd=2)
            }
        }else if(abs(npri)==1){
            for(v in 1:abs(npri)){
                cre = as.numeric(modre[v])
                cellip = as.numeric(modellip[v])
                cpa = as.numeric(modpa[v])
                lines(ellipse(xcen=plotxcen, ycen=plotycen, a=cre/pixsize, e=cellip, pa=cpa), col="green3", lwd=2)
            }
        }
        if(max(sb[[1]]$r)<=10){
            steps = 1; elty = 2
        }
        if(length(sb[[1]]$r) >= ((steps/stepsize)+1)){
            for(p in seq((steps/stepsize)+1,length(sb[[1]]$r),by=(steps/stepsize))){  # every 5 arcseconds
                ells = ellipse(xcen=plotxcen, ycen=plotycen, a=sb[[1]]$r[p]/pixsize, e=sb[[1]]$e[p], pa=sb[[1]]$pa[p])
                lines(ells,col="lightblue",lty=elty)
            }
        }else{
            for(p in 1:5){
                ells = ellipse(xcen=plotxcen, ycen=plotycen, a=p/pixsize, e=prfellip, pa=prfpa)
                lines(ells,col="lightblue",lty=elty)
            }
        }
        
    }else{
        
        image(1:dim(pfmod$mat)[1], 1:dim(pfmod$mat)[2], pfmod$mat, col = pfmod$col, asp = 1, axes = FALSE, xlab = "", ylab = "")
        
    }
    label(pos="topleft", txt="Detail", whitespace=0.1, col="white", bgcol=acol("grey25",a=0.5), bty="b", bordercol="black", lwd=0, cex=labcex, align="center")
    legend("bottomleft", legend=c("primary","secondary (1D mask)", "secondary (2D mask)"), fill=c(acol("purple",a=0.25),acol("green3",a=0.5),acol("orange",a=0.5)), border=NA, ncol=1, bty="n", cex=0.5)
    
    # 1D light profiles
    par("mar"=c(0,5.1,1.1,1.1))
    
    if(file.exists(modim)){
        
        skylim = zp-2.5*log10(skyrms/(pixsize^2))
        if(skylim>zp){
            skylim = min(c(max(sb[[1]]$sb),zp))
            if(is.na(skylim)){skylim=zp}
        }
        maxmark = max(sb[[1]]$r)
        if(any(skylim < sb[[1]]$sb)){
            maxmark = sb[[1]]$r[which(skylim < sb[[1]]$sb)[1]]
        }
        xlim = c(min(sb[[1]]$r),min(c(max(sb[[1]]$r),maxmark)))
        ylim = c(skylim,min(sb[[1]]$sb))
        aplot(sb[[1]]$r, sb[[1]]$sb, xlim=xlim, ylim=ylim, xlab="", ylab=bquote(paste(mu," / mag ",arcsec^{-2})), pch=16, labels=2)
        if(npri>0){
            abline(h=skylim, lty=5, col="grey")
        }
        if(abs(npri)>1){
            for(j in 1:abs(npri)){
                lines(sb[[j+3]]$r, sb[[j+3]]$sb, col=cols[j])  
            }
        }
        arrows(sb[[1]]$r, sb[[1]]$sblo, sb[[1]]$r, sb[[1]]$sbhi, length=0, col="green3")
        lines(sb[[2]]$r, sb[[2]]$sb, col="green3")
        
    }else{
        
        aplot(0, 0, type="n")
        
    }
    
    # model values
    insetstart = 2.4
    insetstep = -0.7
    for(v in 1:abs(npri)){
        txt1 = paste("Comp. #", v, sep="")
        txt2 = paste("\nm = ", modmag10[v], "\nrₑ = ", modre[v], "''\nn = ", modindex[v], "\ne = ", modellip[v], "\n𝛳 = ", modpa[v], "°", sep="")
        if(abs(npri)>1){
            txt2 = paste(txt2, "\nf = ", modfrac10[v], sep="")
        }
        if(abs(npri) == 1){
            label(pos = "topleft", txt=txt1, align="left", inset=c((insetstart+(insetstep*(v-1))),0.1), col="green3")
        }else{
            label(pos = "topleft", txt=txt1, align="left", inset=c((insetstart+(insetstep*(v-1))),0.1), col=cols[v])
        }
        label(pos = "topleft", txt=txt2, align="left", inset=c((insetstart+(insetstep*(v-1))),0.1))
    }
    if(abs(npri)>1){
        txt = paste("m₊ = ", formatC(modmag10tot,format="f",digits=2), "\n\n", sep="")
        label(pos = "left", txt=txt, align="left", inset=insetstart)
    }else if(abs(npri)==1){
        txt = paste("m₊ = ", formatC(modmag10tot,format="f",digits=2), "\n\n", sep="")
        label(pos = "left", txt=txt, align="left", inset=insetstart)
    }
    
    legend("bottomleft", legend=c("Image", "Model"), bty="n", title="1D Measure", pch=c(16,NA), lty=c(NA,1), col=c("black", "green3"), inset=c(0.02,0.02))
    mtext(side=1, text=paste("BIC = ", modbic, "\nP: Χ²/𝜈 = ", formatC(modprichi2,format="f",digits=2), "\nG: Χ²/𝜈 = ", formatC(modgalchi2,format="f",digits=2), sep=""), line=-1.5, outer=TRUE, cex=0.65, adj=0, at=0.51)
    if(file.exists(modim)){
        if(length(sb[[1]]$r)==1){
            label(pos="centre", txt="\n\n\n1D Measurement Error", col="red", cex=1.5)
        }
    }else{
        label(pos="centre", txt="\n\n\n2D Modelling Error", col="red", cex=1.5)
    }
    abox()
    
    # 1D residual
    par("mar"=c(5.1,5.1,0,1.1))
    
    if(file.exists(modim)){
    
        aplot(sb[[1]]$r, sb[[1]]$sb-sb[[2]]$sb, xlim=xlim, ylim=c(-1,1), pch=16, xlab="Radius / arcsec", ylab=bquote(paste(Delta,mu)), nymaj=3, nymin=3)
        abline(h=0, col="grey")
        points(sb[[1]]$r, sb[[1]]$sb-sb[[2]]$sb, pch=16)
        
    }else{
        
        aplot(0, 0, type="n")
        abline(h=0, col="grey")
        
    }
    abox()
    
    # clean up and finish
    graphics.off()
    
}

