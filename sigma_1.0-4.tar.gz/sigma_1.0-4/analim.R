#!/usr/bin/Rscript --no-init-file
# SIGMA (Structural Investigation of Galaxies via Model Analysis)
# Written by Lee Kelvin

# analysis plot setup
analim = function(bandnum = 1, galdat){
    
    # model definitions
    modids = strsplit(strsplit(galdat[,"MODID"], " ")[[1]][bandnum], ",")[[1]]
    modims = strsplit(strsplit(galdat[,"MODIM"], " ")[[1]][bandnum], ",")[[1]]
    mskims = strsplit(strsplit(galdat[,"MSKIM"], " ")[[1]][bandnum], ",")[[1]]
    subims = paste(modids, "_subcomps.fits", sep="")
    models = grep("feedme",dir(moddir),value=T)
    
    # input definitions - definitely should exist
    galname = galdat[,"GALNAME"]
    if("SURVEY" %in% colnames(galdat)){
        galsurvey = toupper(strsplit(galdat[,"SURVEY"], " ")[[1]][bandnum])
    }else{
        galsurvey = ""
    }
    galband = strsplit(galdat[,"BAND"], " ")[[1]][bandnum]
    psfim = strsplit(galdat[,"PSFIM"], " ")[[1]][bandnum]
    pixsize = as.numeric(strsplit(as.character(galdat[,"PIXSIZE"]), " ")[[1]][bandnum])
    zp = as.numeric(strsplit(as.character(galdat[,"MAGZP"]), " ")[[1]][bandnum])
    cutaxis1 = as.numeric(strsplit(as.character(galdat[,"CUTAXIS1"]), " ")[[1]][bandnum])
    cutaxis2 = as.numeric(strsplit(as.character(galdat[,"CUTAXIS2"]), " ")[[1]][bandnum])
    fitaxis1 = as.numeric(strsplit(as.character(galdat[,"FITAXIS1"]), " ")[[1]][bandnum])
    fitaxis2 = as.numeric(strsplit(as.character(galdat[,"FITAXIS2"]), " ")[[1]][bandnum])
    fitxcen = as.numeric(strsplit(as.character(galdat[,"FITXCEN"]), " ")[[1]][bandnum])
    fitycen = as.numeric(strsplit(as.character(galdat[,"FITYCEN"]), " ")[[1]][bandnum])
    sky = 0
    skyrms = as.numeric(strsplit(as.character(galdat[,"SKYSD"]), " ")[[1]][bandnum])
    skyerr = skyrms / sqrt(0.90 * cutaxis1 * cutaxis2)
    pstamp = "pstamp.fits"
    forcefit = as.numeric(strsplit(as.character(galdat[,"PIXSEP"]), " ")[[1]][bandnum])==null
    if(gama){
        plotscale = gamascale[which(gamabands == band[bandnum])]
    }else{
        if(length(plotscale) > 1){
            plotscale = plotscale[bandnum]
        }
    }
    
    # input definitions - SExtractor
    prfmag = as.numeric(strsplit(as.character(galdat[,"MAG_AUTO"]), " ")[[1]][bandnum])
    prfmag10 = as.numeric(strsplit(as.character(galdat[,"MAG_AUTO"]), " ")[[1]][bandnum])
    prfre = as.numeric(strsplit(as.character(galdat[,"SEXRE"]), " ")[[1]][bandnum])
    if(modims[1] != null & file.exists(modims[1])){prfre = prfre * pixsize}
    prfindex = 1
    prfellip = as.numeric(strsplit(as.character(galdat[,"ELLIPTICITY"]), " ")[[1]][bandnum])
    prfpa = as.numeric(strsplit(as.character(galdat[,"THETA_IMAGE"]), " ")[[1]][bandnum])
    prfxcen = fitxcen
    prfycen = fitycen
    prfxoff = prfxcen - fitxcen
    prfyoff = prfycen - fitycen
    
#    # input definitions - variable
#    if("M01_GALMAG_01" %in% colnames(galdat)){
#        
#        prfmag = as.numeric(strsplit(as.character(galdat[,"M01_GALMAG_01"]), " ")[[1]][bandnum])
#        prfmag10 = as.numeric(strsplit(as.character(galdat[,"M01_GALMAG10RE_01"]), " ")[[1]][bandnum])
#        prfre = as.numeric(strsplit(as.character(galdat[,"M01_GALRE_01"]), " ")[[1]][bandnum])
#        if(modims[1] != null & file.exists(modims[1])){prfre = prfre * pixsize}
#        prfindex = as.numeric(strsplit(as.character(galdat[,"M01_GALINDEX_01"]), " ")[[1]][bandnum])
#        prfellip = as.numeric(strsplit(as.character(galdat[,"M01_GALELLIP_01"]), " ")[[1]][bandnum])
#        prfpa = as.numeric(strsplit(as.character(galdat[,"M01_GALPA_01"]), " ")[[1]][bandnum])
#        prfxcen = as.numeric(strsplit(as.character(galdat[,"M01_GALXCEN_01"]), " ")[[1]][bandnum])
#        prfycen = as.numeric(strsplit(as.character(galdat[,"M01_GALYCEN_01"]), " ")[[1]][bandnum])
#        prfxoff = prfxcen - fitxcen
#        prfyoff = prfycen - fitycen
#        
#    }else{
#        
#        prfmag = as.numeric(strsplit(as.character(galdat[,"MAG_AUTO"]), " ")[[1]][bandnum])
#        prfmag10 = as.numeric(strsplit(as.character(galdat[,"MAG_AUTO"]), " ")[[1]][bandnum])
#        prfre = as.numeric(strsplit(as.character(galdat[,"SEXRE"]), " ")[[1]][bandnum])
#        if(modims[1] != null & file.exists(modims[1])){prfre = prfre * pixsize}
#        prfindex = 1
#        prfellip = as.numeric(strsplit(as.character(galdat[,"ELLIPTICITY"]), " ")[[1]][bandnum])
#        prfpa = as.numeric(strsplit(as.character(galdat[,"THETA_IMAGE"]), " ")[[1]][bandnum])
#        prfxcen = fitxcen
#        prfycen = fitycen
#        prfxoff = prfxcen - fitxcen
#        prfyoff = prfycen - fitycen
#        
#    }
    
    # loop over each model
    for(i in 1:length(modids)){
        
        # model-specific definitions
        modid = modids[i]
        modim = modims[i]
        mskim = mskims[i]
        subim = subims[i]
        modname = paste(strsplit(strsplit(models[i], ".feedme")[[1]],"_")[[1]][-1],collapse="")
        
        # parameters
        parlist = c("allxcen", "allycen", "allmag", "allmag10", "allre", "allindex", "allellip", "allpa", "allfrac", "allfrac10")
        parnames = paste(modid, c("_GALXCEN_", "_GALYCEN_", "_GALMAG_", "_GALMAG10RE_", "_GALRE_", "_GALINDEX_", "_GALELLIP_", "_GALPA_", "_GALFRACL_", "_GALFRACL10RE_"), sep="")
        
        for(k in 1:length(parlist)){
            
            # assign parameter
            temp = grep(parnames[k], colnames(galdat))
            if(length(temp)>0){
                assign(parlist[k], as.character(galdat[,temp]))
            }
            
        }
        
        # loop over each primary component and extract bandnum data
        modxcen = {}
        modycen = {}
        modmag = {}
        modmag10 = {}
        modre = {}
        modindex = {}
        modellip = {}
        modpa = {}
        modfrac = {}
        modfrac10 = {}
        for(k in 1:length(allpa)){
            
            # extract raw band component data
            tempxcen = as.numeric(strsplit(allxcen[k]," ")[[1]][bandnum])
            tempycen = as.numeric(strsplit(allycen[k]," ")[[1]][bandnum])
            tempmag = as.numeric(strsplit(allmag[k]," ")[[1]][bandnum])
            tempmag10 = as.numeric(strsplit(allmag10[k]," ")[[1]][bandnum])
            tempre = as.numeric(strsplit(allre[k]," ")[[1]][bandnum])
            tempindex = as.numeric(strsplit(allindex[k]," ")[[1]][bandnum])
            tempellip = as.numeric(strsplit(allellip[k]," ")[[1]][bandnum])
            temppa = as.numeric(strsplit(allpa[k]," ")[[1]][bandnum])
            tempfrac = as.numeric(strsplit(allfrac[k]," ")[[1]][bandnum])
            tempfrac10 = as.numeric(strsplit(allfrac10[k]," ")[[1]][bandnum])
            
            # correct raw values for printing only if GALFIT finished correctly
            if(modim != null & file.exists(modim)){
                
                if(tempxcen!=null){tempxcen = formatC(tempxcen, digits=2, format="f")}
                if(tempycen!=null){tempycen = formatC(tempycen, digits=2, format="f")}
                if(tempmag!=null){tempmag = formatC(tempmag, digits=2, format="f")}
                if(tempmag10!=null){tempmag10 = formatC(tempmag10, digits=2, format="f")}else{tempmag10=tempmag}
                if(tempre!=null){tempre = formatC(tempre*pixsize, digits=2, format="f")}
                if(tempindex!=null){tempindex = formatC(tempindex, digits=2, format="f")}
                if(tempellip!=null){tempellip = formatC(tempellip, digits=2, format="f")}
                if(temppa!=null){temppa = formatC(temppa, digits=1, format="f")}
                if(tempfrac!=null){tempfrac = formatC(tempfrac, digits=2, format="f")}
                if(tempfrac10!=null){tempfrac10 = formatC(tempfrac10, digits=2, format="f")}
                
            }
            
            # add results to global
            modxcen = c(modxcen, tempxcen)
            modycen = c(modycen, tempycen)
            modmag = c(modmag, tempmag)
            modmag10 = c(modmag10, tempmag10)
            modre = c(modre, tempre)
            modindex = c(modindex, tempindex)
            modellip = c(modellip, tempellip)
            modpa = c(modpa, temppa)
            modfrac = c(modfrac, tempfrac)
            modfrac10 = c(modfrac10, tempfrac10)
            
        }
        
        # calculate xoff/yoff only if GALFIT finished correctly for this model
        if(modim != null & file.exists(modim)){
            
            modxoff = paste(as.numeric(modxcen) - fitxcen, collapse=",")
            modyoff =  paste(as.numeric(modycen) - fitycen, collapse=",")
            
        }else{
            
            modxoff = modxcen
            modyoff = modycen
            
        }
        
        # collapse model values with a ','
        modxoff =  paste(modxoff, collapse=",")
        modyoff =  paste(modyoff, collapse=",")
        modmag = paste(modmag, collapse=",")
        modmag10 = paste(modmag10, collapse=",")
        modre = paste(modre, collapse=",")
        modindex = paste(modindex, collapse=",")
        modellip = paste(modellip, collapse=",")
        modpa = paste(modpa, collapse=",")
        modfrac = paste(modfrac, collapse=",")
        modfrac10 = paste(modfrac10, collapse=",")
        
        # extract raw band global data
        modxlo = as.numeric(strsplit(as.character(galdat[,paste(modid,"_GALXLO",sep="")]), " ")[[1]][bandnum])
        modxhi = as.numeric(strsplit(as.character(galdat[,paste(modid,"_GALXHI",sep="")]), " ")[[1]][bandnum])
        modylo = as.numeric(strsplit(as.character(galdat[,paste(modid,"_GALYLO",sep="")]), " ")[[1]][bandnum])
        modyhi = as.numeric(strsplit(as.character(galdat[,paste(modid,"_GALYHI",sep="")]), " ")[[1]][bandnum])
        modmagtot = as.numeric(strsplit(as.character(galdat[,paste(modid,"_GALMAGTOT",sep="")]), " ")[[1]][bandnum])
        modmag10tot = as.numeric(strsplit(as.character(galdat[,paste(modid,"_GALMAG10RETOT",sep="")]), " ")[[1]][bandnum])
        if(modmag10tot==null){modmag10tot = modmagtot}
        modgalchi2 = as.numeric(strsplit(as.character(galdat[,paste(modid,"_GALCHI2",sep="")]), " ")[[1]][bandnum])
        modprichi2 = as.numeric(strsplit(as.character(galdat[,paste(modid,"_PRICHI2",sep="")]), " ")[[1]][bandnum])
        modbic = as.numeric(strsplit(as.character(galdat[,paste(modid,"_BIC",sep="")]), " ")[[1]][bandnum])
        
        # correct raw values for printing only if GALFIT finished correctly
        if(modim != null & file.exists(modim)){
            
            modxlo = formatC(modxlo, digits=0, format="f")
            modxhi = formatC(modxhi, digits=0, format="f")
            modylo = formatC(modylo, digits=0, format="f")
            modyhi = formatC(modyhi, digits=0, format="f")
            modmagtot = formatC(modmagtot, digits=2, format="f")
            modmag10tot = formatC(modmag10tot, digits=2, format="f")
            modgalchi2 = formatC(modgalchi2, digits=2, format="f")
            modprichi2 = formatC(modprichi2, digits=2, format="f")
            modbic = formatC(modbic, digits=0, format="f")
            
        }
        
        if(modim != null & file.exists(modim)){
        
            # read model FITS image
            modimdat = read.fits(modim)
            
            # pick out gain and exposure time
            gain = modimdat$hdr[[2]][which(modimdat$hdr[[2]][,"key"]=="GAIN"),"value"]
            exptime = modimdat$hdr[[2]][which(modimdat$hdr[[2]][,"key"]=="EXPTIME"),"value"]
        
        }else{
            
            gain = exptime = null
            
        }
        
        # FITS header extras
        hdrkeys = c("COMMENT", "COMMENT", "COMMENT", "GALNAME", "SURVEY", "BAND", "MODID", "MODNAME", "MODIM", "MSKIM", "SUBIM", "FORCEFIT", "PIXSIZE", "FITXCEN", "FITYCEN", "PRFMAG", "PRFMAG10", "PRFRE", "PRFINDEX", "PRFELLIP", "PRFPA", "PRFXOFF", "PRFYOFF", "SKY", "SKYERR", "SKYRMS", "ZP", "GAIN", "EXPTIME", "MODXLO", "MODXHI", "MODYLO", "MODYHI", "MODXOFF", "MODYOFF", "MODMAG", "MODMAG10", "MODRE", "MODINDEX", "MODELLIP", "MODPA", "MODF", "MODF10", "MODMT", "MODM10T", "MODGCHI2", "MODPCHI2", "MODBIC", "COMMENT", "COMMENT", "COMMENT", "PTYPE", "PSLIDE", "PSCALE", "PLO", "PHI", "PINV")
        hdrvals = c("", "", "", galname, galsurvey, galband, modid, modname, modim, mskim, subim, as.character(forcefit), pixsize, fitxcen, fitycen, prfmag, prfmag10, prfre, prfindex, prfellip, prfpa, prfxoff, prfyoff, sky, skyerr, skyrms, zp, gain, exptime, modxlo, modxhi, modylo, modyhi, modxoff, modyoff, modmag, modmag10, modre, modindex, modellip, modpa, modfrac, modfrac10, modmagtot, modmag10tot, modgalchi2, modprichi2, modbic, "", "", "", plotftype, plotslide, plotscale, plotlocut, plothicut, plotinvert)
        hdrcoms = c("", "#########################", "", "Galaxy name", "Survey", "Band", "Model ID", "Model name", "Model FITS image", "Mask FITS image", "Subcomponent FITS image", "Has the model been force fitted?", "Pixel size (arcsec/pixel)", "Input centroid (x)", "Input centroid (y)", "M01 magnitude", "M01 truncated magnitude", "M01 half-light radius", "M01 Sersic index", "M01 ellipticity", "M01 position angle", "M01 x-offset", "M01 y-offset", "Sky (ADUs)", "Error on the sky (ADUs)", "Sky RMS (ADUs)", "Zero point", "Gain", "Exposure time", "Model lower x fitting limit", "Model upper x fitting limit", "Model lower y fitting limit", "Model upper y fitting limit", "Model x-offset", "Model y-offset", "Model magnitude", "Model truncated magnitude", "Model half-light radius", "Model Sersic index", "Model ellipticity", "Model position angle", "Model luminosity fraction", "Model truncated luminosity fraction", "Model total magnitude", "Model total truncated magnitude", "Model GALFIT Chi2", "Model primary Chi2", "Model BIC", "", "#########################", "", "Plotting function type", "Plotting slide values", "Plotting scale values", "Plotting lower-cut", "Plotting upper-cut", "Plotting invert?")
        
        # add data to FITS headers
        if(modim != null & file.exists(modim)){
            
            # update model FITS image
            modimdat$hdr[[1]] = rbind(modimdat$hdr[[1]], cbind(hdrkeys, hdrvals, hdrcoms))
            write.fits(modimdat, file=modim)
            
        }
        
        # add data to postage stamp header
        stampdat = read.fits(pstamp)
        modkeys = which(hdrkeys!="COMMENT")
        hdrkeys[modkeys] = paste(modid,"_",hdrkeys[modkeys], sep="")
        stampdat$hdr[[1]] = rbind(stampdat$hdr[[1]], cbind(hdrkeys, hdrvals, hdrcoms))
        write.fits(stampdat, file=pstamp)
        
    }
    
    # add modids to header
    write.fitskey(key = c("COMMENT", "COMMENT", "COMMENT", "MODIDS"), value = c("", "", "", paste(modids,collapse=",")), file = pstamp, comment = c("", "#########################", "", "Model ID's (full list)"))
    
    # copy and modify sigmaplot.R file
    file.copy(paste(sigmadir, "/sigmaplot.R", sep=""), ".")
    system("chmod uog+x sigmaplot.R")
    
    # execute plotting code?
    if(makeplot){
        
        #cat("----- analim :", band[bandnum], ": making analysis image(s)... ")
        system("./sigmaplot.R")
        #cat("analysis image(s) created!\n\n")
        
    }
    
}

