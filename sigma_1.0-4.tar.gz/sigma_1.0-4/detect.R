#!/usr/bin/Rscript --no-init-file
# SIGMA (Structural Investigation of Galaxies via Model Analysis) model generator
# Written by Lee Kelvin

# object detection
detect = function(bandnum = 1, galdat){
    
    # input definitions
    cutim = strsplit(galdat[,"CUTIM"], " ")[[1]][bandnum]
    cutwt = strsplit(galdat[,"CUTWT"], " ")[[1]][bandnum]
    psffwhm = as.numeric(strsplit(as.character(galdat[,"PSFFWHM"]), " ")[[1]][bandnum])
    pixsize = as.numeric(strsplit(as.character(galdat[,"PIXSIZE"]), " ")[[1]][bandnum])
    cutxcen = as.numeric(strsplit(as.character(galdat[,"CUTXCEN"]), " ")[[1]][bandnum])
    cutycen = as.numeric(strsplit(as.character(galdat[,"CUTYCEN"]), " ")[[1]][bandnum])
    cutaxis1 = as.numeric(strsplit(as.character(galdat[,"CUTAXIS1"]), " ")[[1]][bandnum])
    cutaxis2 = as.numeric(strsplit(as.character(galdat[,"CUTAXIS2"]), " ")[[1]][bandnum])
    zp = as.numeric(strsplit(as.character(galdat[,"MAGZP"]), " ")[[1]][bandnum])
    minlim = plotsize
    
    # identify Gaussian convolution kernels
    gaussconvs = unlist(strsplit(unlist(strsplit(detconfig,".sex")),paste(outdir,"/configs/",sep="")))
    if(any(gaussconvs=="")){gaussconvs = gaussconvs[-which(gaussconvs=="")]}
    gaussconvs = paste(outdir, "/", gaussconvs, ".conv", sep="")
    
    # output definitions
    base = strsplit(cutim,"cutim")[[1]][2]
    if(is.na(base)){base = strsplit(cutim,"simim")[[1]][2]}
    objct = paste(strsplit(paste("objct",base,sep=""),".fit")[[1]][1],".dat",sep="")
    segim = paste("segim",base,sep="")
    fitim = paste("fitim",base,sep="")
    if(cutwt!="NA"){
        fitwt = paste("fitwt",base,sep="")
    }else{
        fitwt = "NA"
    }
    
    # source extract setup
    arglist = list(WEIGHT_TYPE = "NONE", WEIGHT_IMAGE = cutwt, STARNNW_NAME = nnw, CATALOG_NAME = objct, CATALOG_TYPE = "ASCII_HEAD", CHECKIMAGE_TYPE = "NONE", CHECKIMAGE_NAME = segim, MAG_ZEROPOINT = zp, PIXEL_SCALE = pixsize, SEEING_FWHM = psffwhm, FILTER_NAME = gaussconvs[length(gaussconvs)], BACK_TYPE = "MANUAL", BACK_VALUE = 0)
    if(cutwt!="NA"){arglist$WEIGHT_TYPE = "MAP_WEIGHT"}
    
    # loop over each detect configuration (simply to acquire a global thresholding level for each)
    threshlevels = {}
    for(i in 1:length(detconfig)){
        
        # setup
        arglist$CHECKIMAGE_TYPE = "NONE"
        arglist$CHECKIMAGE_NAME = segim
        arglist$FILTER_NAME = gaussconvs[i]
        detconf = detconfig[i]
        
        # build source extractor command
        sexcommand = buildsex(sex, cutim, detconf, detparam, arglist)
        
        # run source extractor
        output = system(sexcommand, intern=TRUE)
        
        # pick-out thresholding level
        thresh = as.numeric(strsplit(grep("/ Threshold: ", output, value=T), "/ Threshold: ")[[1]][2])
        threshlevels = c(threshlevels, thresh)
        
    }
    
    # number of detected
    detected = as.numeric(strsplit(strsplit(grep("Objects: detected ", output, value=T), "Objects: detected ")[[1]][2], " +")[[1]][1])
    
    # only continue if any objects found
    d = NA
    if(detected > 0){
        
        # read in catalogue data
        d = read.table(arglist$CATALOG_NAME)
        colnames(d) = cnames(arglist$CATALOG_NAME)
        d[,"PIXSEP"] = (((d[,"X_IMAGE"]-cutxcen)^2) + ((d[,"Y_IMAGE"]-cutycen)^2))^0.5
        
        # object found?
        if(min(d[,"PIXSEP"]) < minpixsep){
            objectfound = TRUE
            objinfo = d[which.min(d[,"PIXSEP"])[1],]
        }else{
            objectfound = FALSE
        }
        
    }else{
        
        objectfound = FALSE
        
    }
    
    if(fitsize!=0){
        
        # fitting limits
        xlo = max(1, round(cutxcen - fitsize))
        xhi = min(cutaxis1, round(cutxcen + fitsize))
        ylo = max(1, round(cutycen - fitsize))
        yhi = min(cutaxis2, round(cutycen + fitsize))
        xrange = xlo:xhi
        yrange = ylo:yhi
        
    }else if(objectfound){
        
        # primary object parameters
        a = fitfact*objinfo[,"A_IMAGE"]*objinfo[,"KRON_RADIUS"]
        e = objinfo[,"ELLIPTICITY"]
        theta = objinfo[,"THETA_IMAGE"]
        b = a * (1-e)
        
        # fitting limits
        xlo = max(1, (cutxcen - round(cutaxis1 * 0.4)))
        xhi = min(cutaxis1, (cutxcen + round(cutaxis1 * 0.4)))
        ylo = max(1, (cutycen - round(cutaxis2 * 0.4)))
        yhi = min(cutaxis2, (cutycen + round(cutaxis2 * 0.4)))
        
        # fitting limits
        xlim = ceiling(sqrt(((a^2)*((cos(-theta*(pi/180)))^2)) + ((b^2)*((sin(-theta*(pi/180)))^2))))
        ylim = ceiling(sqrt(((a^2)*((sin(-theta*(pi/180)))^2)) + ((b^2)*((cos(-theta*(pi/180)))^2))))
        if(xlim<minlim){xlim = minlim}
        if(ylim<minlim){ylim = minlim}
        xrange = cutxcen + (-xlim:xlim)
        yrange = cutycen + (-ylim:ylim)
        if(any(xrange<xlo)){xrange = xrange[xrange>=xlo]}
        if(any(yrange<ylo)){yrange = yrange[yrange>=ylo]}
        if(any(xrange>xhi)){xrange = xrange[xrange<=xhi]}
        if(any(yrange>yhi)){yrange = yrange[yrange<=yhi]}
        
    }else{
        
        # fitting limits
        xlo = max(1, round(cutxcen - minlim))
        xhi = min(cutaxis1, round(cutxcen + minlim))
        ylo = max(1, round(cutycen - minlim))
        yhi = min(cutaxis2, round(cutycen + minlim))
        xrange = xlo:xhi
        yrange = ylo:yhi
        
    }
    
    # create fitting images
    if(file.exists(fitim)){file.remove(fitim)}
    cutcommandim = paste(fitscopy," ",cutim,"[",format(min(xrange),scientific=FALSE),":",format(max(xrange),scientific=FALSE),",",format(min(yrange),scientific=FALSE),":",format(max(yrange),scientific=FALSE),"] ",fitim,sep="")
    system(cutcommandim)
    if(fitwt!="NA"){
        if(file.exists(fitwt)){file.remove(fitwt)}
        cutcommandwt = paste(fitscopy," ",cutwt,"[",format(min(xrange),scientific=FALSE),":",format(max(xrange),scientific=FALSE),",",format(min(yrange),scientific=FALSE),":",format(max(yrange),scientific=FALSE),"] ",fitwt,sep="")
        system(cutcommandwt)
    }
    
    # dimensional info
    cutim.dat = read.fits(cutim)
    fitaxis1 = length(xrange)
    fitaxis2 = length(yrange)
    fitxcen = which(xrange==cutxcen)
    fitycen = which(yrange==cutycen)
    
    # make postage stamp
    tempdat = read.fits(fitim)
    #tempdat = cutim.dat
    tempdat$dat[[1]] = imtrim(input = tempdat$dat[[1]], xcen = fitxcen, ycen = fitycen, trim = minlim)
    write.fits(tempdat$dat[[1]], file=paste("pstamp",base,sep=""))
    
    # loop over each sextractor configuration
    fits = {}
    dats = {}
    cats = {}
    ells = {}
    dets = {}
    for(i in 1:length(detconfig)){
        
        # setup
        detbase = paste("det", i, sep="")
        arglist$WEIGHT_IMAGE = fitwt
        arglist$CATALOG_NAME = paste(detbase, ".dat", sep="")
        arglist$CHECKIMAGE_TYPE = "SEGMENTATION"
        arglist$CHECKIMAGE_NAME = paste(detbase, ".fits", sep="")
        arglist$FILTER_NAME = gaussconvs[i]
        detconf = detconfig[i]
        
        # thresholding levels
        detfile = readLines(detconf)
        detectsigma = as.numeric(strsplit(grep("DETECT_THRESH",detfile, value=T), " +")[[1]][2])
        analysissigma = as.numeric(strsplit(grep("ANALYSIS_THRESH",detfile, value=T), " +")[[1]][2])
        arglist$THRESH_TYPE = "ABSOLUTE"
        arglist$DETECT_THRESH = threshlevels[i]
        arglist$ANALYSIS_THRESH = threshlevels[i] * analysissigma/detectsigma
        
        # add to global lists
        fits = c(fits, arglist$CHECKIMAGE_NAME)
        dats = c(dats, arglist$CATALOG_NAME)
        
        # build source extractor command
        sexcommand = buildsex(sex, fitim, detconf, detparam, arglist)
        
        # run source extractor
        output = system(sexcommand, intern=TRUE)
        
        # number of detected
        detected = as.numeric(strsplit(strsplit(grep("Objects: detected ", output, value=T), "Objects: detected ")[[1]][2], " +")[[1]][1])
        dets = c(dets, detected)
        
        # only continue if any objects found
        if(detected > 0){
            
            # read in catalogue data
            d = read.table(arglist$CATALOG_NAME)
            colnames(d) = cnames(arglist$CATALOG_NAME)
            d[,"PIXSEP"] = (((d[,"X_IMAGE"]-fitxcen)^2) + ((d[,"Y_IMAGE"]-fitycen)^2))^0.5
            cats = c(cats, list(d))
            
            # create ellipse image
            if(i!=length(detconfig)){
                
                m = matrix(0, fitaxis1, fitaxis2)
                for(j in 1:length(d[,1])){
                    
                    # definitions
                    objdat = d[j,]
                    objval = objdat[,"NUMBER"]
                    xcen = round(objdat[,"X_IMAGE"])
                    ycen = round(objdat[,"Y_IMAGE"])
                    a = objdat[,"A_IMAGE"]*objdat[,"KRON_RADIUS"]
                    e = objdat[,"ELLIPTICITY"]
                    theta = objdat[,"THETA_IMAGE"]
                    b = a * (1-e)
                    
                    # calculate upper x and y limits for smaller sub-box and x/y ranges
                    xlim = ceiling(sqrt(((a^2)*((cos(-theta*(pi/180)))^2)) + ((b^2)*((sin(-theta*(pi/180)))^2))))
                    ylim = ceiling(sqrt(((a^2)*((sin(-theta*(pi/180)))^2)) + ((b^2)*((cos(-theta*(pi/180)))^2))))
                    xrange = xcen + (-xlim:xlim)
                    yrange = ycen + (-ylim:ylim)
                    if(any(xrange<1)){xrange = xrange[xrange>=1]}
                    if(any(yrange<1)){yrange = yrange[yrange>=1]}
                    if(any(xrange>fitaxis1)){xrange = xrange[xrange<=fitaxis1]}
                    if(any(yrange>fitaxis2)){yrange = yrange[yrange<=fitaxis2]}
                    
                    # calculate ellipse values
                    temp = ell(xcen = xcen, ycen = ycen, a = a, e = e, theta = theta, xseq = xrange, yseq = yrange)
                    
                    # add values to global matrix
                    #m[xrange,yrange][which(temp<1)] = m[xrange,yrange][which(temp<1)] + 1
                    m[xrange,yrange][which(temp<1)] = objval
                    
                }
                
                # add to global ellipse file
                ells = c(ells, list(m))
                
            }
        
        }else{
            
            cats = c(cats, list(NA))
            ells = c(ells, list(NA))
            
        }
        
    }
    
    # no objects found at all in new reduced fitting region
    if(objectfound & length(unique(unlist(cats)))==1){
        
        objectfound = FALSE
        
    }
    
    # HDR SExtractor
    if(length(fits)>1){
        
        # create master catalogue
        for(i in length(fits):2){
            
            # definitions
            coldcat = cats[[i-1]]
            hotcat = cats[[i]]
            coldim = ells[[i-1]]
            coldseg = fits[i-1]
            hotseg = read.fits(fits[i])
            detected = dets[i]
            
            # only continue if any objects found
            if(detected > 0){
                
                # any detections in cold catalogue?
                if(is.na(as.matrix(coldcat)[1,1])){
                    
                    coldcat = hotcat
                    
                }else{
                    
                    # below deemed unreliable, kept for reference
                    ## identify primary object in cold cat (for upwards protection)
                    #if(min(coldcat[,"PIXSEP"]) < searchrad){
                    #    pricoldnum = which.min(coldcat[,"PIXSEP"])[1]
                    #}else{
                    #    pricoldnum = 0
                    #}
                    
                    ## identify primary object in hot cat (for upwards protection)
                    #if(min(hotcat[,"PIXSEP"]) < searchrad){
                    #    prihotnum = which.min(hotcat[,"PIXSEP"])[1]
                    #}else{
                    #    prihotnum = 0
                    #}
                    
                    # loop over each hot object
                    for(j in 1:length(hotcat[,1])){
                        
                        # object params
                        objdat = hotcat[j,]
                        xcen = round(objdat[,"X_IMAGE"])
                        ycen = round(objdat[,"Y_IMAGE"])
                        
                        # check for hot-cold overlaps
                        if((coldim[xcen,ycen]==0)){
                            
                            # add to coldcat if not in cold image
                            coldcat = rbind(coldcat, objdat)
                            
                        }else{
                            
                            # find entry in cold catalogue and modify hot catalogue
                            coldval = coldim[xcen,ycen]
                            hotcat[j,"NUMBER"] = -coldval
                            
                        }
                        
                    }
                    
                }
                
                # update cold segmentation image
                numbers = unique(sort(hotcat[,"NUMBER"]))
                if(any(numbers<0)){
                    
                    # identify
                    npos = numbers[numbers>0]
                    nneg = numbers[numbers<0]
                    
                    # loop over each positive number
                    if(length(npos) > 0){
                        for(j in 1:length(npos)){
                            
                            hotcat[which(hotcat[,"NUMBER"]==npos[j]),"NUMBER"] = (min(nneg)-1)
                            nneg = c((min(nneg)-1), nneg)
                            
                        }
                    }
                    
                    # loop over each hot object, and update segmentation value
                    for(j in 1:length(hotcat[,1])){
                        
                        # object params
                        objdat = hotcat[j,]
                        xcen = round(objdat[,"X_IMAGE"])
                        ycen = round(objdat[,"Y_IMAGE"])
                        hotnum = objdat[,"NUMBER"]
                        objval = hotseg$dat[[1]][xcen,ycen]
                        
                        # update values
                        hotseg$dat[[1]][hotseg$dat[[1]]==objval] = hotnum
                        
                    }
                    
                    # update cold number values
                    coldcat[,"NUMBER"] = 1:length(coldcat[,1])
                    
                    # loop over each cold object, and update segmentation value
                    for(j in 1:length(coldcat[,1])){
                        
                        # object params
                        objdat = coldcat[j,]
                        xcen = round(objdat[,"X_IMAGE"])
                        ycen = round(objdat[,"Y_IMAGE"])
                        coldnum = objdat[,"NUMBER"]
                        objval = hotseg$dat[[1]][xcen,ycen]
                        
                        # update values
                        hotseg$dat[[1]][hotseg$dat[[1]]==objval] = coldnum
                        
                    }
                    
                    # overwrite cold segmentation image
                    write.fits(hotseg, file=coldseg)
                    
                }
                
                # update cats
                cats[[i-1]] = coldcat
                
            }
            
        }
        
        # master catalogue
        d = cats[[1]]
        
    }
    
    if(length(d) > 1){
        
        # remove secondary satellite trails
        if(any(d[,"ELLIPTICITY"] > 0.95)){
            bad = which(d[,"ELLIPTICITY"] > 0.95)
            d = d[-bad,]    # remove line-like objects (satellite trails and such)
        }
        
        # size values for aperture correction below (in arcsec, where appropriate)
        fluxrad = pixsize*d[,"FLUX_RADIUS"]
        a = pixsize*d[,"A_IMAGE"]
        b = pixsize*d[,"B_IMAGE"]
        
        # correct half-light radii for circular apertures and PSF
        sqre = ((fluxrad^2)*(a/b)) - (0.32*((psffwhm)^2))
        sqre[sqre<(pixsize^2)]=(pixsize^2)
        d[,"SEXRE"] = sqrt(sqre)/pixsize    # pixels
        
        # calculate idealised surface-brightness values
        sexmag = as.numeric(d[,"MAG_AUTO"])
        sexre = as.numeric(d[,"SEXRE"]) * pixsize
        sexellip = as.numeric(d[,"ELLIPTICITY"])
        s0n1 = suppressWarnings(sersic(mag = sexmag, re = sexre, n = 1, e = sexellip, r = 0*sexre))
        s0n4 = suppressWarnings(sersic(mag = sexmag, re = sexre, n = 4, e = sexellip, r = 0*sexre))
        s1n1 = suppressWarnings(sersic(mag = sexmag, re = sexre, n = 1, e = sexellip, r = 1*sexre))
        s1n4 = suppressWarnings(sersic(mag = sexmag, re = sexre, n = 4, e = sexellip, r = 1*sexre))
        d[,"SEXMU0N1"] = s0n1$mu
        d[,"SEXMU0N4"] = s0n4$mu
        d[,"SEXMUEN1"] = s1n1$mu
        d[,"SEXMUEN4"] = s1n4$mu
        
        # update detection catalogue
        write.table(d, objct, quote=FALSE, row.names=FALSE)
        
    }else{
        
        unlink(objct)
        
    }
    
    # clean up
    if(consistentmask & bandnum > 1){
        file.copy(paste("../",band[1],"/",segim,sep=""), segim)
    }else{
        file.copy(fits[1], segim)
    }
    unlink(fits)
    unlink(dats)
    
    # check primary object still found
    if(objectfound & (length(d) > 1)){
        if(min(d[,"PIXSEP"]) < minpixsep){
            objectfound = TRUE
            objinfo = d[which.min(d[,"PIXSEP"])[1],]
        }else{
            objectfound = FALSE
        }
    }
    
    # assign primary object info
    if(objectfound){
        
        # primary data
        prinum = which.min(d[,"PIXSEP"])[1]
        objinfo = d[prinum,]
        d = d[-prinum,]
        
        # remove secondary objects much fainter than primary (3 mags)
        if(length(d) > 2){
            magdiff = objinfo[,"MAG_AUTO"] - d[,"MAG_AUTO"]
            if(any(magdiff < -3)){
                bad = which(magdiff < -3)
                d = d[-bad,]
            }
        }
        
        # add RA/Dec information
        temp = system(paste(xy2sky, "-d", cutim, objinfo[,"X_IMAGE"], objinfo[,"Y_IMAGE"]), intern=TRUE)
        temp = as.numeric(strsplit(temp, " +")[[1]][1:2])
        objinfo[,"SEXRA"] = temp[1]
        objinfo[,"SEXDEC"] = temp[2]
        
    }else{
        
        if(force){
            
            # no object found - forced input
            sexparams = c(as.vector(t(read.table(detparam))), "PIXSEP", "SEXRE", "SEXMU0N1", "SEXMU0N4", "SEXMUEN1", "SEXMUEN4", "SEXRA", "SEXDEC")
            objinfo = galdat[0]
            for(i in 1:length(sexparams)){objinfo = cbind(objinfo, null)}
            colnames(objinfo) = sexparams
            
            if(length(d) < 2){
                
                d = objinfo
                
            }
            
            objinfo[,"X_IMAGE"] = fitxcen
            objinfo[,"Y_IMAGE"] = fitycen
            objinfo[,"FLUX_RADIUS"] = objinfo[,"KRON_RADIUS"] = objinfo[,"SEXRE"] = max(fitxcen,fitycen) * 0.2
            objinfo[,"A_IMAGE"] = objinfo[,"B_IMAGE"] = 1
            objinfo[,"THETA_IMAGE"] = 0
            objinfo[,"ELLIPTICITY"] = 0
            objinfo[,"MAG_AUTO"] = zp - 10
            
            # calculate idealised surface-brightness values
            sexmag = as.numeric(objinfo[,"MAG_AUTO"])
            sexre = as.numeric(objinfo[,"SEXRE"]) * pixsize
            sexellip = as.numeric(objinfo[,"ELLIPTICITY"])
            s0n1 = suppressWarnings(sersic(mag = sexmag, re = sexre, n = 1, e = sexellip, r = 0*sexre))
            s0n4 = suppressWarnings(sersic(mag = sexmag, re = sexre, n = 4, e = sexellip, r = 0*sexre))
            s1n1 = suppressWarnings(sersic(mag = sexmag, re = sexre, n = 1, e = sexellip, r = 1*sexre))
            s1n4 = suppressWarnings(sersic(mag = sexmag, re = sexre, n = 4, e = sexellip, r = 1*sexre))
            objinfo[,"SEXMU0N1"] = s0n1$mu
            objinfo[,"SEXMU0N4"] = s0n4$mu
            objinfo[,"SEXMUEN1"] = s1n1$mu
            objinfo[,"SEXMUEN4"] = s1n4$mu
            
        }else{
            
            # no object found - not forced
            sexparams = c(as.vector(t(read.table(detparam))), "PIXSEP", "SEXRE", "SEXMU0N1", "SEXMU0N4", "SEXMUEN1", "SEXMUEN4", "SEXRA", "SEXDEC")
            faked = galdat[0]
            for(i in 1:length(sexparams)){faked = cbind(faked, null)}
            colnames(faked) = sexparams
            objinfo = faked
            
            if(length(d) < 2){
                
                d = objinfo
                
            }
            
        }
        
    }
    
    # npri and nsec
    npri = length(which(objinfo[,1] != null))
    nsec = length(which(d[,1] != null))
    
    # update results
    extras = galdat[0]
    checklist = c(list(FITIM=fitim, FITWT=fitwt, OBJCT=objct, SEGIM=segim, FITAXIS1=fitaxis1, FITAXIS2=fitaxis2), FITXCEN=fitxcen, FITYCEN=fitycen, NPRI=npri, NSEC=nsec, as.list(objinfo))
    for(i in 1:length(checklist)){
        
        if(names(checklist)[i]%in%colnames(galdat)){
            col = which(colnames(galdat)==names(checklist)[i])[1]
            galdat[,col] = paste(galdat[,col], checklist[[i]])
        }else{
            extras = cbind(extras, checklist[[i]])
            colnames(extras)[length(colnames(extras))] = names(checklist)[i]
        }
        
    }
    
    # return results
    galdat = cbind(galdat, extras, stringsAsFactors=FALSE)
    return(list(galdat=galdat, objlist=d))
    
}

# create a trimmed image, with a border of zeroes if necessary
imtrim = function(input, xcen, ycen, trim = 50){
    
    # axes
    axis1 = dim(input)[1]
    axis2 = dim(input)[2]
    paxis1 = ((trim*2)+1)
    paxis2 = ((trim*2)+1)
    pxcen = trim + 1
    pycen = trim + 1
    
    # input limits
    xlo = max((round(xcen) - trim), 1)
    xhi = min((round(xcen) + trim), axis1)
    ylo = max((round(ycen) - trim), 1)
    yhi = min((round(ycen) + trim), axis2)
    
    # mapped limits
    pxlo = (pxcen-xcen) + xlo
    pxhi = (pxcen-xcen) + xhi
    pylo = (pycen-ycen) + ylo
    pyhi = (pycen-ycen) + yhi
    pdat = matrix(0, paxis1, paxis2)
    pdat[pxlo:pxhi,pylo:pyhi] = input[xlo:xhi,ylo:yhi]
    
    # return results
    return(pdat)
    
}

